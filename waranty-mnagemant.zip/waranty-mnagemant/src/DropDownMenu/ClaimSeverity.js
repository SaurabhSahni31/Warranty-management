import React from "react";

class ClaimSeverity extends React.Component {
  constructor() {
    super();

    this.state = {
      displayClaim: false
    };

    this.showDropdownClaim = this.showDropdownClaim.bind(this);
    this.hideDropdownClaim = this.hideDropdownClaim.bind(this);
  }

  showDropdownClaim(event) {
    event.preventDefault();
    this.setState({ displayClaim: true }, () => {
      document.addEventListener("click", this.hideDropdownClaim);
    });
  }

  hideDropdownClaim() {
    this.setState({ displayClaim: false }, () => {
      document.removeEventListener("click", this.hideDropdownClaim);
    });
  }

  render() {
    return (
      <div className="dropdown">
        <div className="button" onClick={this.showDropdownClaim}>
          Claim Severity{" "}
        </div>

        {this.state.displayClaim ? (
          <ul>
            <li>
              <a className="active">High</a>
            </li>
            <li>
              <a>Medium</a>
            </li>
            <li>
              <a>Low</a>
            </li>
          </ul>
        ) : null}
      </div>
    );
  }
}

export default ClaimSeverity;
