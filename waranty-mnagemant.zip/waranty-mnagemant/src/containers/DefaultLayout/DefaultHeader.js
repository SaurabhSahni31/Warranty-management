import React, { Component } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Badge, UncontrolledDropdown, DropdownItem,ButtonDropdown, DropdownMenu, DropdownToggle, Nav, NavItem } from 'reactstrap';
import PropTypes from 'prop-types';
import img from '../../assets/img/1.png';
import { AppAsideToggler, AppNavbarBrand, AppSidebarToggler } from '@coreui/react';

const propTypes = {
  children: PropTypes.node,
};

const defaultProps = {};


class DefaultHeader extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      dropdownOpen: false
    };
  }
  toggle() { 
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  }
  render() {

    // eslint-disable-next-line
    const { children, ...attributes } = this.props;

    return (
      <React.Fragment>
        <AppSidebarToggler className="d-lg-none" display="md" mobile />
           <AppNavbarBrand>
              <img src={img} width="80%" alt="cmplify@gmail.com"></img> 
            </AppNavbarBrand> 
        
        <AppSidebarToggler className="d-md-down-none" display="lg" />

 
        <Nav className="ml-auto" navbar>
          <NavItem className="d-md-down-none">
          <ButtonDropdown  isOpen={this.state.dropdownOpen} toggle={this.toggle}>
                  <DropdownToggle caret color="success"size="sm">
                   CREATE
                  </DropdownToggle>
                  <DropdownMenu >
                    <DropdownItem >
                      <i className="icon-cursor-move icons  d-block m-t1 cmp-black title-cmp"><a className="cmp-displayNone" href="/#/Services/Services"> CREATE SERVICE</a></i>
                    </DropdownItem>
                    <DropdownItem >
                      <i className="icon-cursor-move icons  d-block m-t1 cmp-black title-cmp"><a className="cmp-displayNone" href="/#/Claims/Claims"> CREATE CLAIMS</a></i>
                    </DropdownItem>
                    <DropdownItem >
                      <i className="icon-cursor-move icons  d-block m-t1 cmp-black title-cmp"><a className="cmp-displayNone" href="/#/Products/product">CREATE PRODUCT</a></i>
                    </DropdownItem>
                    
                 </DropdownMenu>
                </ButtonDropdown>
          </NavItem>
          <NavItem className="d-md-down-none">
          <UncontrolledDropdown nav direction="down">
            <DropdownToggle nav>
            <i className="icon-bell"></i>
            </DropdownToggle>
            <DropdownMenu >
              <DropdownItem header tag="div" className="text-center"> <strong>All Notification</strong></DropdownItem>
              <DropdownItem  style={{color:'cornflowerblue',fontWeight:'bold'}}><i className="fa fa-cog"></i> Services<Badge color="info">17</Badge></DropdownItem>
              <DropdownItem style={{textAlign:'center'}}>Recent Services</DropdownItem>
              <DropdownItem style={{textAlign:'center'}}><strong>Classic Motors</strong></DropdownItem>
              <DropdownItem style={{textAlign:'center'}}><strong>	Borg Warner Inc.</strong></DropdownItem>
            
              <DropdownItem style={{color:'cornflowerblue',fontWeight:'bold'}}><i className="fa fa-list-alt"></i> Claims<Badge color="warning">12</Badge></DropdownItem>
              <DropdownItem style={{textAlign:'center'}}>Recent Claims</DropdownItem>
              <DropdownItem style={{textAlign:'center'}}><strong>Engine, Chrysler</strong></DropdownItem>
              <DropdownItem style={{textAlign:'center'}}><strong>Drivetrain, General Motors</strong></DropdownItem>
  
              <DropdownItem style={{color:'cornflowerblue',fontWeight:'bold'}}><i className="fa fa-shopping-cart"></i> Product<Badge color="danger">8</Badge></DropdownItem>
              <DropdownItem style={{textAlign:'center'}}>Recent Products</DropdownItem>
              <DropdownItem style={{textAlign:'center'}}><strong>Brake Pads</strong></DropdownItem>
              <DropdownItem style={{textAlign:'center'}}><strong>Valve train</strong></DropdownItem>
            </DropdownMenu>
          </UncontrolledDropdown>
          </NavItem>
          <NavItem className="d-md-down-none">
            <NavLink to="#" className="nav-link"><i className="icon-envelope"></i></NavLink>
          </NavItem>

          <UncontrolledDropdown nav direction="down">
            <DropdownToggle nav>
              <img src={'../../assets/img/avatars/1.png'} className="img-avatar" alt="admin@bootstrapmaster.com" />
            </DropdownToggle>
            <DropdownMenu right>
              <DropdownItem><i className="fa fa-bell-o"></i> Status : Online</DropdownItem>
              <DropdownItem href="/login#/UserSetting/MyAccount"><i className="fa fa-envelope-o"></i> My Account Setting</DropdownItem>
              <DropdownItem href="/login#/login"><i className="fa fa-tasks"></i> Logout</DropdownItem>
            </DropdownMenu>
          </UncontrolledDropdown>
        </Nav>
        <AppAsideToggler className="d-md-down-none" />
        {/*<AppAsideToggler className="d-lg-none" mobile />*/}
      </React.Fragment>
    );
  }
}

DefaultHeader.propTypes = propTypes;
DefaultHeader.defaultProps = defaultProps;

export default DefaultHeader;
