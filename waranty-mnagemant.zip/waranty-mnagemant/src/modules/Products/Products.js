import React, { Component } from 'react';

class Products extends Component {

    render() {
        return (
            <div className="App">
                <header className="App-header">

                    <p>
                        Products
                    </p>

                </header>
            </div>
        );
    }

}

export default Products;
