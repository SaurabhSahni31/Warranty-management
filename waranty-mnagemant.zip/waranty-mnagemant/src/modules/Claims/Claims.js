import React, { Component } from 'react';

class Claims extends Component {

    render() {
        return (
            <div className="App">
                <header className="App-header">

                    <p>
                        Claims
                    </p>

                </header>
            </div>
        );
    }

}

export default Claims;
