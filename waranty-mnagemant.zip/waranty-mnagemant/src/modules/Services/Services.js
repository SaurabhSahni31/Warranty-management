import React, { Component } from 'react';

class Services extends Component {

    render() {
        return (
            <div className="App">
                <header className="App-header">

                    <p>
                        Services
                    </p>

                </header>
            </div>
        );
    }

}

export default Services;
