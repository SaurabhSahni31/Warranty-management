import React, { Component } from 'react';

class Warranty extends Component {

    render() {
        return (
            <div className="App">
                <header className="App-header">

                    <p>
                        Warranty
                    </p>

                </header>
            </div>
        );
    }

}

export default Warranty;
