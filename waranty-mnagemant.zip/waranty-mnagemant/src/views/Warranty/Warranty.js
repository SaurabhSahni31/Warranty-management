import React, { Component } from 'react';
import { Button, Col, Row, FormGroup, InputGroup, Input, InputGroupAddon, Card, Label, Badge, CardHeader, CardBody,Modal,ModalBody, Table,  Pagination, PaginationItem, PaginationLink} from 'reactstrap';

var data=require('../Warranty/Warranty.json')

 
class Warranty extends Component {
    constructor(props) {
        super(props);
        this.state={ 
          modal: false,
          modal1:false,
          warrantyData:data
        }
       
        this.toggle1 = this.toggle1.bind(this);
    }
  
      toggle(Id) {
        this.setState({
          modal: !this.state.modal,
          warrantyId:Id
        });
      }
      toggle1() {
          this.setState({
            modal1: !this.state.modal1,
          });
        }
        handleClick() {
          alert('Request has been sent !', this);
        }
    render() { 
      var warrantyForModal=[];
      if(this.state.warrantyId)
      {
        this.state.warrantyData.map(warranty =>{
            if(warranty.id===this.state.warrantyId)
            {warrantyForModal.push(warranty);}
        });
      }
        return ( 

            <div className="animated fadeIn  p-t3">
              {/* Modal for viewing a warranty */}
               <Modal isOpen={this.state.modal} toggle= {this.toggle.bind(this)} className={this.props.className}>
                  <ModalBody>
                    {warrantyForModal.map(warranty=>
                        <Card>
                        <CardBody>
                            <FormGroup>
                              <h4 className="center">ID-{warranty.id},{warranty.product}</h4>
                            </FormGroup>
                            <FormGroup className="pl-1 pr-1">
                              <Label className="modal-title-cmp">Warranty Type</Label>
                              <Card className="modal-card-bg p-l10"><Label className="fs-1 p-t5px">{warranty.warrantyType}</Label></Card>
                            </FormGroup>
                            <FormGroup className="pl-1 pr-1">
                              <Label className="modal-title-cmp">Status</Label>
                              <Card className="modal-card-bg p-l10"><Label className="fs-1 p-t5px">{warranty.status}</Label></Card>
                            </FormGroup>
                            <FormGroup className="pl-1 pr-1" >
                              <Label className="modal-title-cmp">Warranty Start Date</Label>
                              <Card className="modal-card-bg p-l10"><Label className="fs-1 p-t5px">{warranty.warrantyStartDate}</Label></Card>
                            </FormGroup>
                            <FormGroup className="pl-1 pr-1">
                              <Label className="modal-title-cmp">Warranty End Date</Label>
                              <Card className="modal-card-bg p-l10"><Label className="fs-1 p-t5px">{warranty.warrantyEndDate}</Label></Card>
                            </FormGroup>
                            <Button onClick={this.toggle.bind(this)}  outline color="danger" className="m-l1" >CANCEL</Button>
                            {warranty.status==="Under Warranty" ? <Button disabled onClick={this.toggle1} className="btn btn-success cmp-floatRight m-r1" >EXTEND WARRANTY</Button>:
                            <Button  onClick={this.toggle1} className="btn btn-success cmp-floatRight m-r1" >EXTEND WARRANTY</Button>}
                
                          </CardBody>
                        </Card>
                    )}  
                  </ModalBody>
                </Modal>

                {/*Modal for Extending warranty */}
                <Modal isOpen={this.state.modal1} toggle={this.toggle1} className={this.props.className} size="xl">
                  <ModalBody className="modal-bg-gray">
                        <Card className="m-12 p-3">
                          <Row className="mt-3">
                            <Col className="center">
                            <h2>Do you want to Extend the Warranty ?</h2>
                            </Col>
                          </Row>
                          <Row className="mt-3 mb-3">
                            <Col sm='6'>
                              <Button onClick={this.toggle1}  className="btn btn-danger btn-lg pl-2 m-l1" >CANCEL</Button>
                            </Col>
                            <Col sm='6'> 
                              <Button onClick={(e) => this.handleClick(e)}  className="btn btn-success btn-lg pl-2 cmp-floatRight">SEND REQUEST</Button>
                            </Col>
                          </Row>
                        </Card>    
                  </ModalBody>
                </Modal>

            <Col xs="12" lg="12" md="12" className="p-lr0">  
              <Card>
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">WARRANTY</h5>
                                    </Col> 
                                    <Col className="cmp-pr-0">
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="cmp-searchBar-width"  placeholder="Search for Warranty ID...." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>
                        
                  <Table responsive striped size="lg" >
                    <thead>
                        <tr>
                        <th>PRODUCT</th>
                        <th className="center">WARRANTY POLICY</th>
                        <th>WARRANTY TYPE</th>
                        <th className="center">WARRANTY PERIOD</th>
                        <th>STATUS</th>
                        <th>  </th>
                        </tr>
                    </thead>
                    <tbody>
                      {this.state.warrantyData.map(warranty=>
                           <tr>
                              <td>
                                  <p className="title-cmp">{warranty.product}</p>
                              </td>
                              <td className="center">
                                <p>{warranty.warrantyPolicy}</p>
                              </td>
                              <td>
                                <p>{warranty.warrantyType}</p>
                              </td>
                              <td className="center">
                                <p className="date-cmp">{warranty.warrantyStartDate} - {warranty.warrantyEndDate}</p>
                              </td>
                              <td>
                              {warranty.status === "Under Warranty" ? <Badge color="success">{warranty.status}</Badge>
                                      : <Badge color="danger">{warranty.status}</Badge>}
                              </td>
                              <td><Button type="button" size="sm" color="info" onClick= {this.toggle.bind(this, warranty.id)} >View</Button></td>
                          </tr>
                        )}
                       
                   </tbody>
                  </Table>
                  </CardBody>
                  </Card>

                  <Pagination className="pagin">
                    <PaginationItem>
                      <PaginationLink previous tag="button"></PaginationLink>
                    </PaginationItem>
                    <PaginationItem active>
                      <PaginationLink tag="button">1</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink tag="button">2</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink tag="button">3</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink next tag="button"></PaginationLink>
                    </PaginationItem>
                  </Pagination> 
   
            </Col>
        </div>
         );
    }
}
 
export default Warranty;