import React, {Component} from 'react';
import {HorizontalBar} from 'react-chartjs-2';

const data = {
  labels: ['HARNESS', 'DRIVE SHAFT', 'HOSE & LINE MATERIAL', 'STARTERS', 'BEARINGS'],
  datasets: [{
      label: 'Spare Cost (USD)',
      type:'horizontalBar',
      data: [1559, 845, 829, 816, 646],
      fill: false,
      borderColor: '#FF6384',
      backgroundColor: '#FF6384',
      pointHoverBackgroundColor: '#FF6384',
    },{
      type: 'horizontalBar',
      label: 'Spare Qty.',
      data: [5, 4, 4, 5, 8],
      fill: false,
      backgroundColor: '#36A2EB',
      borderColor: '#36A2EB',
      hoverBackgroundColor: '#36A2EB',
    }]
};

const options ={
  scales: {
    tooltips: {
      callbacks: {
         label: function(t, d) {
            var xLabel = d.datasets[t.datasetIndex].label;
            var yLabel = t.yLabel >= 1000 ? + t.yLabel.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : + t.yLabel;
            return xLabel + ': ' + yLabel;
         }
      }
   },
      xAxes: [{
          gridLines: {
              display:false
          },
          ticks: {
            callback: function(value, index, values) {             
              if (value >= 1E6) {
                return  value / 1000000 + 'M';
              }
              else if (value>= 1e3 || value >1e6){
                return value / 1000 + 'k' ;
              }
              else return  value ;
            }
          },
          scaleLabel: {
            display: true,
            labelString: 'Spare Parts Cost & Total Qty.'
          }
        }],
        yAxes: [{
            gridLines: {
                display:true
            }   
        }]
}};

export default class PartsMixsdBarGraph extends Component {
  render() {
    return (
      <div>
        <HorizontalBar
          data={data}
          options={options}
        />
      </div>
    );
  }
}