import React, {Component} from 'react';
import {HorizontalBar} from 'react-chartjs-2';


const data = {
  labels: ['CLASSIC MOTOR INC', 'DOLPHIN DEALER INC', 'BESPOKE MOTOR GROUP', 'OZARA CAR INC', 'T2T, LTC'],
  datasets: [{
      label: 'Labor Cost',
      type:'horizontalBar',
      data: [4129416.56, 3570797.60, 1934881.80, 1428359.28, 1350731.20],
      fill: false,
      borderColor: '#FF6384',
      backgroundColor: '#FF6384',
      pointHoverBackgroundColor: '#FF6384',
    },{
      type: 'horizontalBar',
      label: 'Labor Hour',
      data: [156653000, 140619000, 77833000, 54024000, 53118000],
      fill: false,
      backgroundColor: '#36A2EB',
      borderColor: '#36A2EB',
      hoverBackgroundColor: '#36A2EB',
    }]
};

const options ={
    scales: {
      tooltips: {
        callbacks: {
            label: function(t, d) {
               var xLabel = d.datasets[t.datasetIndex].label;
               var yLabel = t.yLabel >= 1000 ? + t.yLabel.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : + t.yLabel;
               return xLabel + ': ' + yLabel;
            }          
        }
      },
        xAxes: [{
            gridLines: {
                display:true
            },
            ticks: {
              callback: function(value, index, values) {             
                if (value >= 1E6) {
                  return  value / 1000000 + 'M';
                }
                else if (value>= 1e3 || value >1e6){
                  return value / 1000 + 'k' ;
                }
                else return  value ;
              }
            },
            scaleLabel: {
              display: true,
              labelString: 'Labor Cost (USD) & Labor Hours'
            }
            
        }],
        yAxes: [{
            gridLines: {
                display:false
            }
        }]
}};

export default class MixedBar extends Component {
  render() {
    return (
      <div>
        <HorizontalBar
          data={data}
          options={options}
          height= "160px"
          width= "321px"
        />
      </div>
    );
  }
}