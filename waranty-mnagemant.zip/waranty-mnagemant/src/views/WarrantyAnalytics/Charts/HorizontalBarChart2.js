import React, { Component } from 'react';
import {HorizontalBar} from 'react-chartjs-2';

const data = {
  labels: ['Bearings', 'A/C Repair', 'Breake pads & shoes', 'Harness ', 'Driver airbag issue'],
  datasets: [
    {
        label: '',
      backgroundColor: [
        '#FF6384', 
        '#20A8D8',                      
        '#FFC107',
        '#4DBD74',
        '#63C2DE',
        ],
      hoverBackgroundColor: [
        '#FF6384', 
        '#20A8D8',                      
        '#FFC107',
        '#4DBD74',
        '#63C2DE',
      ],
      data: [8232, 7836, 5768, 5444, 5262]
    }
  ]
};
const options ={
    legend: {
      display: false
    },
    scales: {
      tooltips: {
        callbacks: {
           label: function(t, d) {
              var xLabel = d.datasets[t.datasetIndex].label;
              var yLabel = t.yLabel >= 1000 ? + t.yLabel.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : + t.yLabel;
              return xLabel + ': ' + yLabel;
           }
        }
     },
        xAxes: [{
            gridLines: {
                display:false
            },
            ticks: {
              callback: function(value, index, values) {             
                if (value >= 1E6) {
                  return  value / 1000000 + 'M';
                }
                else if (value>= 1e3 || value >1e6){
                  return value / 1000 + 'k' ;
                }
                else return  value ;
              }
            },
            scaleLabel: {
              display: true,
              labelString: 'Cost',
              fontSize: 13,
            } 
        }],
        yAxes: [{
            gridLines: {
                display:false
            },
            scaleLabel: {
              display: true,
              labelString: 'Types of Services',
              fontSize: 13,
            }   
        }]
}};

export default class HorizontalBarChart2 extends Component {

  render() {
    return (
      <div>
        <HorizontalBar data={data} options={options} />
      </div>
    );
  }
}