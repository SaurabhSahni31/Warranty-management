import React, {Component} from 'react';
import {Bar} from 'react-chartjs-2';

const data = {
  labels: ['1', '2', '3', '4', '5', '6', ['7', '2017'], '8', '9', '10', '11', '12','1', '2', '3', '4', '5', '6', ['7', '2018'], '8',
   '9','10', '11', '12'],
  datasets: [{
    type: 'line',
    label: 'Projected',
    data: [209, 195, 194, 153, 224, 360, 456, 410, 279, 243, 226, 205, 207, 217, 201, 196, 151, 330,
    428, 385, 266, 226, 216, 205, 211],
    fill: false,
    borderCapStyle: 'butt',
    pointBorderWidth: 3,
    pointHoverRadius: 6,
    backgroundColor: '#4DBD74',
    borderColor: '#4DBD74',
    hoverBackgroundColor: '#4DBD74',
  },
    {
      label: 'Actual',
      type:'bar',
      data: [209, 195, 194, 153, 224, 360, 456, 410, 279, 220, 226, 205],
      fill: false,
      borderColor: '#FFC107',
      backgroundColor: '#FFC107',
      pointHoverBackgroundColor: '#FFC107',
    }]
};

const options ={
    scales: {
        xAxes: [{
            gridLines: {
                display:false
            },
            scaleLabel: {
              display: true,
              labelString: 'Months and Year'
            }
        }],
        yAxes: [{
            gridLines: {
                display:false
            },
            ticks: {
              callback: function(value, index, values) {             
                if (value >= 1E6) {
                  return  value / 1000000 + 'M';
                }
                else if (value>= 1e3 || value >1e6){
                  return value / 1000 + 'k' ;
                }
                else return  value ;
              }
            }  
        }]
    }
};

export default class MixedLineBar2 extends Component {
  render() {
    return (
      <div>
        <Bar
          data={data}
          options={options}
        />
      </div>
    );
  }
}