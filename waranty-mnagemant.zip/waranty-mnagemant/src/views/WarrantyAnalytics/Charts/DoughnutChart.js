import React, {Component} from 'react';
import {  Doughnut } from 'react-chartjs-2';

const doughnut = {
  labels: [
    'Limited RWD',
    '200C FWD',
    '200A FWD',
  ],
  datasets: [
    {
      data: [44.82, 28.36, 26.79],
      backgroundColor: [
        '#FF6384',
        '#36A2EB',
        '#FFCE56',
      ],
      hoverBackgroundColor: [
        '#FF6384',
        '#36A2EB',
        '#FFCE56',
      ],
    }],
};

  export default class DoughnutChart extends Component {
    render() {
      return (
        <div className="m-b">
          <Doughnut className="chartjs-render-monitor" data={doughnut}/>
        </div>
      );
    }
  }