import React, {Component} from 'react';
import {Bar} from 'react-chartjs-2';

const data = {
  labels: ['1', '2', '3', '4', '5', '6', ['7', '2017'], '8', '9', '10', '11', '12', '1', '2', '3', '4', '5', '6',['7', '2018'], '8',
   '9','10', '11', '12'],
   axisX:{
    labelFontSize: 20
  },
  datasets: [{
    type: 'line',
    label: 'Projected',
    data: [2253, 2226, 2482, 2407, 2397, 2370, 2508, 2451, 2418, 2225, 2314, 2553, 2153, 2126, 2189, 2186, 2142, 2223,
    2310, 2274, 2280, 2088, 2162, 2281],
    fill: false,
    borderCapStyle: 'butt',
    pointBorderWidth: 3,
    pointHoverRadius: 6,
    backgroundColor: '#36A2EB',
    borderColor: '#36A2EB',
    hoverBackgroundColor: '#36A2EB',
  },
    {
      label: 'Actual',
      type:'bar',
      data: [2253, 2226, 2482, 2407, 2397, 2370, 2508, 2451, 2418, 2225, 2539, 2335],
      fill: false,
      borderColor: '#FF6384',
      backgroundColor: '#FF6384',
      pointHoverBackgroundColor: '#FF6384',
    }]
};

const options ={
    scales: {
        xAxes: [{
            gridLines: {
                display:false
            },
            scaleLabel: {
              display: true,
              labelString: 'Months and Year'
            }
        }],
        yAxes: [{
            gridLines: {
                display:false
            },
            ticks: {
              callback: function(value, index, values) {             
                if (value >= 1E6) {
                  return  value / 1000000 + 'M';
                }
                else if (value>= 1e3 || value >1e6){
                  return value / 1000 + 'k' ;
                }
                else return  value ;
              }
            }   
        }]
    }
};

export default class MixedLineBar extends Component {
  render() {
    return (
      <div>
        <Bar 
          data={data}
          options={options}
        />
      </div>
    );
  }
}