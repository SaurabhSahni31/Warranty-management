import React, {Component} from 'react';
import {Bar} from 'react-chartjs-2';

const data = {
  labels: ['1', '2', '3', '4', '5', '6', ['7', '2017'], '8', '9', '10', '11', '12','1', '2', '3', '4', '5', '6', ['7', '2018'], '8',
   '9','10', '11', '12'],
  datasets: [{
    type: 'line',
    label: 'Projected',
    data: [348, 378, 348, 364, 360, 341, 332, 283, 317, 351, 284, 302, 312, 311, 294, 304,
      320, 322, 321, 317, 261, 271],
    fill: false,
    borderCapStyle: 'butt',
    pointBorderWidth: 3,
    pointHoverRadius: 6,
    backgroundColor: '#4DBD74',
    borderColor: '#4DBD74',
    hoverBackgroundColor: '#4DBD74',
    },
    {
      label: 'Actual',
      type:'bar',
      data: [309, 354, 393, 346, 340, 292, 304, 319, 288, 330, 383, 351],
      fill: false,
      borderColor: '#FFC107',
      backgroundColor: '#FFC107',
      pointHoverBackgroundColor: '#FFC107',
    }]
};

const options ={
    scales: {
        xAxes: [{
            gridLines: {
                display:false
            },
            scaleLabel: {
              display: true,
              labelString: 'Months and Year'
            }
        }],
        yAxes: [{
            gridLines: {
                display:false
            },
            ticks: {
              callback: function(value, index, values) {             
                if (value >= 1E6) {
                  return  value / 1000000 + 'M';
                }
                else if (value>= 1e3 || value >1e6){
                  return value / 1000 + 'k' ;
                }
                else return  value ;
              }
            }   
        }]
    }
};

export default class MixedLineBar3 extends Component {
  render() {
    return (
      <div>
        <Bar className="chartjs-render-monitor"
          data={data}
          options={options}
        />
      </div>
    );
  }
}