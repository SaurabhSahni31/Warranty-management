import React, {Component} from 'react';
import {HorizontalBar} from 'react-chartjs-2';

const data = {
  labels: ['BEARINGS', 'AIR FILTERS', 'HARNESS', 'STARTERS', 'HOSE & LINE MATERIAL'],
  datasets: [{
      label: 'Spare Cost (USD)',
      type:'horizontalBar',
      data: [646, 295, 1559, 816, 829],
      fill: false,
      borderColor: '#FF6384',
      backgroundColor: '#FF6384',
      pointHoverBackgroundColor: '#FF6384',
    },{
      type: 'horizontalBar',
      label: 'Total Claims.',
      data: [8, 8, 5, 5, 4],
      fill: false,
      backgroundColor: '#36A2EB',
      borderColor: '#36A2EB',
      hoverBackgroundColor: '#36A2EB',
    }]
};

const options ={
  scales: {
    tooltips: {
      callbacks: {
         label: function(t, d) {
            var xLabel = d.datasets[t.datasetIndex].label;
            var yLabel = t.yLabel >= 1000 ? + t.yLabel.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : + t.yLabel;
            return xLabel + ': ' + yLabel;
         }
      }
   },
      xAxes: [{
          gridLines: {
              display:false
          },
          ticks: {
            callback: function(value, index, values) {             
              if (value >= 1E6) {
                return  value / 1000000 + 'M';
              }
              else if (value>= 1e3 || value >1e6){
                return value / 1000 + 'k' ;
              }
              else return  value ;
            }
          },
          scaleLabel: {
            display: true,
            labelString: 'Spare Parts Cost & Total Claims'
          }
        }],
        yAxes: [{
            gridLines: {
                display:true
            }   
        }]
}};

export default class PartsMixedBarGraph2 extends Component {
  render() {
    return (
      <div>
        <HorizontalBar
          data={data}
          options={options}
        />
      </div>
    );
  }
}