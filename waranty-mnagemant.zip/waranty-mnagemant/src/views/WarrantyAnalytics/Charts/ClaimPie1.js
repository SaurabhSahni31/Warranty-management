import React, {Component} from 'react';
import {  Pie } from 'react-chartjs-2';

const pie = {
    labels: [
      'CLASIC MOTOR INC',
      'DOLPHIN DEALER INC',
      'BESPOKE MOTOR GROUP',
      'OZARA CAR INC',
      'T2T, LTC'
    ],
    datasets: [
      {
        data: [32.78, 28.31, 16.22, 11.41, 11.26],
        backgroundColor: [
          '#FF6384', 
          '#20A8D8',                      
          '#FFC107',
          '#4DBD74',
          '#63C2DE',
        ],
        hoverBackgroundColor: [
          '#FF6384', 
          '#20A8D8',                      
          '#FFC107',
          '#4DBD74',
          '#63C2DE',
        ],
      }],
      options: {
        title: {
          display: true,
          text: 'Claims in Percentage',
          position: 'bottom'
          
        },
          elements: {
              center: {
              text: 'Desktop',
              color: '#36A2EB', //Default black
              fontStyle: 'Helvetica', //Default Arial
              sidePadding: 15 //Default 20 (as a percentage)
            }
          }
        }
  };
  


export default class ClaimPie1 extends Component {
  render() {
    return (
      <div className="m-b">
        <Pie className="chartjs-render-monitor" data={pie}/>
      </div>
    );
  }
}