import React from 'react';
import InputRange from 'react-input-range';
import "react-input-range/lib/css/index.css";
 
class Filter extends React.Component {
    constructor(props) {
        super(props);
     
        this.state = { value: 2016 };
      }
     
      render() {
        return (
          <InputRange
            maxValue={2019}
            minValue={2016}
            value={this.state.value}
            onChange={value => this.setState({ value })} />
        );
      }
    }

export default Filter;