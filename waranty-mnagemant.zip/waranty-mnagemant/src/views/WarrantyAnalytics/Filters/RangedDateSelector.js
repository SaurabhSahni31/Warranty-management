import React, { Component } from 'react';
import { RangeDatePicker } from "@y0c/react-datepicker";
import "@y0c/react-datepicker/assets/styles/calendar.scss";
import "dayjs/locale/ko";
import "dayjs/locale/en";
import '../../../StyleSheet/Default.css';
import {Row, Col} from "reactstrap";

const Panel = ({ header, children }) => (
  <div>
    <div>{children}</div>
  </div>
);

class RangedDateSelector extends Component {
  render() { 
  const onChange = title => (...args) => console.log(title, args);
  return (
    <Row className="p-l2">
      <Col lg="5" md="12" sm="12">
      <Panel>
        <RangeDatePicker onChange={onChange("Range DatePicker")} startPlaceholder="Jul 20, 2019" endPlaceholder="Sep 20, 2019"/>
      </Panel>
      </Col>
    </Row>
    );
  }
}

export default RangedDateSelector;