import React, { Component } from 'react';
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../../StyleSheet/Default.css';
import {Row, Col} from "reactstrap";

const Region = [
    { label: "Region(All)", value: 1 },
    { label: "South", value: 2 },
    { label: "Midwest", value: 3 },
];
const State = [
    { label: "State(All)", value: 1 },
    { label: "MI", value: 2 },
    { label: "SD", value: 3 },
    { label: "TX", value: 4 },
];
const Dealers = [
    { label: "Dealers(All)", value: 1 },
    { label: "Dolphin Dealer INC", value: 2 },
    { label: "Bespoke Motor Group", value: 3 },
    { label: "Classic Motor INC", value: 4 },
    { label: "O'jara Car INC", value: 5 },
];

class SelectState extends Component {
    render() { 
        return ( 
            <Row className="p-l2 p-t1 m-b">
            <Col lg="4" sm="12" md="4" className="m-b">
                <Select options={ Region } placeholder="Region(All)"/>
            </Col>
            <Col lg="4" sm="12" md="4" className="m-b">
                <Select options={ State } placeholder="State(All)" />
            </Col>
            <Col lg="4" sm="12" md="4" className="p-r2">
                <Select options={ Dealers } placeholder="Dealers(All)" />
            </Col>
        </Row>
        );
    }
}
export default SelectState;