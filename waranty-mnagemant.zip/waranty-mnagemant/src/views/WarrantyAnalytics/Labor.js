import React, { Component } from 'react';
import {Row, Col} from "reactstrap";
import '../../StyleSheet/Default.css'
import MixedBar from "./Charts/MixedBar.js";
import MixedBar2 from "./Charts/MixedBar2";
import SelectState from "./Filters/SelectState";
import RangedDateSelector from "./Filters/RangedDateSelector";
import Card from 'react-bootstrap/Card'
import {
    ButtonDropdown,
    ButtonGroup,
    DropdownItem,
    DropdownMenu,
    DropdownToggle,
  } from 'reactstrap';

class Labor extends Component {
    constructor(props) {
        super(props);
    
        this.toggle = this.toggle.bind(this);
    
        this.state = {
          dropdownOpen: false,
        };
      }
    
      toggle() {
        this.setState({
          dropdownOpen: !this.state.dropdownOpen,
        });
      }

    render() { 
        return ( 
            <div className="animated fadeIn p-t3 p-lr4px">
                <div className="col-lg-12 col-md-12 col-sm-12 border p-t1 frame-bg m-b1">

                <Row className=" p-t1">
                    <Col lg="4" sm="12" md="4" className="p-t5px">
                    <Card className="cmp-card cmp-iconCol-warning">
                        <Card.Body>
                            <ButtonGroup className="cmp-floatRight">
                                <ButtonDropdown className="btn-transparent" id='card1' isOpen={this.state.card1} toggle={() => { this.setState({ card1: !this.state.card1 }); }}>
                                <DropdownToggle caret className="p-0" color="transparent">
                                    <i className="icon-settings"></i>
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>Last Week</DropdownItem>
                                    <DropdownItem>Last 15 Days</DropdownItem>
                                    <DropdownItem>Last 30 Days</DropdownItem>
                                </DropdownMenu>
                                </ButtonDropdown>
                            </ButtonGroup>
                            <Card.Title className="m-b0 font-cmp-cardGraph txt-cmp-white">Avg. Labor Cost Per Claim</Card.Title>
                            <Card.Text className="font-sm txt-cmp-white">
                                in USD 
                            </Card.Text>
                            <Card.Text className="font-num txt-cmp-white">
                                200
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                    <Col lg="4" sm="12" md="4" className="p-t5px">
                    <Card className="cmp-card bg-cmp-info">
                        <Card.Body>
                            <ButtonGroup className="cmp-floatRight">
                                <ButtonDropdown className="btn-transparent" id='card2' isOpen={this.state.card2} toggle={() => { this.setState({ card2: !this.state.card2 }); }}>
                                <DropdownToggle caret className="p-0" color="transparent">
                                    <i className="icon-settings"></i>
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>Last Week</DropdownItem>
                                    <DropdownItem>Last 15 Days</DropdownItem>
                                    <DropdownItem>Last 30 Days</DropdownItem>
                                </DropdownMenu>
                                </ButtonDropdown>
                            </ButtonGroup>
                            <Card.Title className="m-b0 font-cmp-cardGraph txt-cmp-white">Avg. Labor Cost Per Hour</Card.Title>
                            <Card.Text className="font-sm txt-cmp-white">
                                in USD 
                            </Card.Text>
                            <Card.Text className="font-num txt-cmp-white">
                            25.75
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                    <Col lg="4" sm="12" md="4" className="p-t5px">
                    <Card className="cmp-card bg-cmp-success">
                        <Card.Body>
                            <ButtonGroup className="cmp-floatRight">
                                <ButtonDropdown className="btn-transparent" id='card3' isOpen={this.state.card3} toggle={() => { this.setState({ card3: !this.state.card3 }); }}>
                                <DropdownToggle caret className="p-0" color="transparent">
                                    <i className="icon-settings"></i>
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>Last Week</DropdownItem>
                                    <DropdownItem>Last 15 Days</DropdownItem>
                                    <DropdownItem>Last 30 Days</DropdownItem>
                                </DropdownMenu>
                                </ButtonDropdown>
                            </ButtonGroup>
                            <Card.Title className="m-b0 font-cmp-cardGraph txt-cmp-white">Avg. Labor Hours Per Claim</Card.Title>
                            <Card.Text className="font-num p-t2 txt-cmp-white">
                                513
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                </Row>

                <div className="col-lg-12 col-md-12 col-sm-12 border padding0 frame-bg m-b1">
                <div className="col-lg-12 col-md-12 col-sm-12 displayFlex padding0 frame-bg m-b1 filter-cmp-bg border-bottom "> 
                       
                       <Row className="p-t1 m-b1" lg="12" sm="12" md="12">
                           <Col lg="8" sm="12" md="12">
                               <SelectState />
                           </Col>
                           <Col lg="4" sm="12" md="12" className="p-t1">
                               <RangedDateSelector />
                           </Col>
                       </Row>
                   </div>

                <div className="col-lg-12 col-md-12 col-sm-12 displayFlex m-b1"> 
                    <div className="col-lg-6 col-md-5 col-sm-5">
                        <p className="p-t1 font">Labor Cost (USD) & Hours By Dealers</p>
                            <MixedBar />
                  </div>
                    <div className="col-lg-6 col-md-5 col-sm-5 ml-4 m-r1">
                        <p className="p-t1 font">Labor Cost (USD) & Claims By Dealers</p>
                            <MixedBar2  />
                    </div>
                  
                </div>
                </div> 
                </div>
            </div>    
        );
    }
}
 
export default Labor;