import React, { Component } from 'react';
import '../../StyleSheet/Default.css'
import ClaimPie1 from './Charts/ClaimPie1.js';
import Doughnut from './Charts/DoughnutChart.js';
import HorizontalBar from './Charts/HorizontalBarChart.js';
import HorizontalBar2 from './Charts/HorizontalBarChart2';
import SelectState from "./Filters/SelectState";
import RangedDateSelector from "./Filters/RangedDateSelector";
import {Col, Row} from 'reactstrap';
import Card from 'react-bootstrap/Card'
import {
    ButtonDropdown,
    ButtonGroup,
    DropdownItem,
    DropdownMenu,
    DropdownToggle,
  } from 'reactstrap';

class Claim extends Component {
    constructor(props) {
        super(props);
    
        this.toggle = this.toggle.bind(this);
    
        this.state = {
          dropdownOpen: false,
        };
      }
    
      toggle() {
        this.setState({
          dropdownOpen: !this.state.dropdownOpen,
        });
      }

    render() { 
        return ( 
            <div className="animated fadeIn p-t3 p-lr4px">
                <div className="col-lg-12 col-md-12 col-sm-12 border p-t1 frame-bg m-b1">

                <Row className=" p-t1">
                    <Col lg="4" sm="12" md="4" className="p-t5px">
                    <Card className="cmp-card cmp-iconCol-warning">
                        <Card.Body>
                            <ButtonGroup className="cmp-floatRight">
                                <ButtonDropdown className="btn-transparent" id='card1' isOpen={this.state.card1} toggle={() => { this.setState({ card1: !this.state.card1 }); }}>
                                <DropdownToggle caret className="p-0" color="transparent">
                                    <i className="icon-settings"></i>
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>Last Week</DropdownItem>
                                    <DropdownItem>Last 15 Days</DropdownItem>
                                    <DropdownItem>Last 30 Days</DropdownItem>
                                    <DropdownItem>Last 3 Months</DropdownItem>
                                </DropdownMenu>
                                </ButtonDropdown>
                            </ButtonGroup>
                            <Card.Title className="m-b0 font-cmp-cardGraph txt-cmp-white">Total Claims</Card.Title>
                            <Card.Text className="font-sm txt-cmp-white">
                                in Thousand 
                            </Card.Text>
                            <Card.Text className="font-num p-t10px txt-cmp-white">
                                66
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                    <Col lg="4" sm="12" md="4" className="p-t5px">
                    <Card className="cmp-card bg-cmp-info">
                        <Card.Body>
                            <ButtonGroup className="cmp-floatRight">
                                <ButtonDropdown className="btn-transparent" id='card2' isOpen={this.state.card2} toggle={() => { this.setState({ card2: !this.state.card2 }); }}>
                                <DropdownToggle caret className="p-0" color="transparent">
                                    <i className="icon-settings"></i>
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>Last Week</DropdownItem>
                                    <DropdownItem>Last 15 Days</DropdownItem>
                                    <DropdownItem>Last 30 Days</DropdownItem>
                                    <DropdownItem>Last 3 Months</DropdownItem>
                                </DropdownMenu>
                                </ButtonDropdown>
                            </ButtonGroup>
                            <Card.Title className="m-b0 font-cmp-cardGraph txt-cmp-white">Total Labor Cost</Card.Title>
                            <Card.Text className="font-sm txt-cmp-white">
                                in Thousand 
                            </Card.Text>
                            <Card.Text className="font-num p-t10px txt-cmp-white">
                                13
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                    <Col lg="4" sm="12" md="4" className="p-t5px">
                    <Card className="cmp-card bg-cmp-success">
                        <Card.Body>
                            <ButtonGroup className="cmp-floatRight">
                                <ButtonDropdown className="btn-transparent" id='card3' isOpen={this.state.card3} toggle={() => { this.setState({ card3: !this.state.card3 }); }}>
                                <DropdownToggle caret className="p-0" color="transparent">
                                    <i className="icon-settings"></i>
                                </DropdownToggle>
                                <DropdownMenu right>
                                    <DropdownItem>Last Week</DropdownItem>
                                    <DropdownItem>Last 15 Days</DropdownItem>
                                    <DropdownItem>Last 30 Days</DropdownItem>
                                    <DropdownItem>Last 3 Months</DropdownItem>
                                </DropdownMenu>
                                </ButtonDropdown>
                            </ButtonGroup>
                            <Card.Title className="m-b0 font-cmp-cardGraph txt-cmp-white">Total Labor Hours</Card.Title>
                            <Card.Text className="font-sm txt-cmp-white">
                                in Thousand 
                            </Card.Text>
                            <Card.Text className="font-num p-t10px txt-cmp-white">
                                513
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                </Row>
               
                <div className="col-lg-12 col-md-12 col-sm-12 border padding0 frame-bg m-b1">
                    <div className="col-lg-12 col-md-12 col-sm-12 displayFlex padding0 frame-bg  filter-cmp-bg border-bottom "> 
                       
                        <Row className="p-t1" lg="12" sm="12" md="12">
                            <Col lg="7" sm="12" md="12">
                                <SelectState />
                            </Col>
                            <Col lg="4" sm="12" md="12" className="m-b1 p-l1 p-t10px">
                                <RangedDateSelector />
                            </Col>
                        </Row>
                    </div>
                
                    <div className="col-lg-12 col-md-12 col-sm-12 displayFlex m-b"> 
                    <div className="col-lg-6 col-md-5 col-sm-4">
                        <p className="p-t1 font">Claims By Dealers</p>
                        <ClaimPie1 />
                    </div>
                    <div className="col-lg-6 col-md-5 col-sm-4 ml-4">
                        <p className="p-t1 font">Claims By Model Type</p>
                        <Doughnut  />
                    </div>
                  
                </div>

                <div className="col-lg-12 col-md-12 col-sm-12 displayFlex m-b"> 
                  <div className="col-lg-6 col-md-5 col-sm-4 border-top">
                    <p className="p-t1 font">Claims By Service</p>
                    <HorizontalBar />
                  </div>
                  <div className="col-lg-6 col-md-5 col-sm-4 border-top ml-4 m-r1">
                    <p className="p-t1 font">Root Cause For Service</p>
                    <HorizontalBar2 />
                  </div>
                </div>
                </div> 
                </div>
            </div>    
        );
    }
}
 
export default Claim;