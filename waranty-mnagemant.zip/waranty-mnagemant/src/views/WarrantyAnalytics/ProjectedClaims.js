import React, { Component } from 'react';
import '../../StyleSheet/Default.css'
import MixedLineBar from './Charts/MixedLineBar.js';
import MixedLineBar2 from "./Charts/MixedLineBar2";
import MixedLineBar3 from "./Charts/MixedLineBar3"

class ProjectedClaims extends Component {
    render() { 
        return ( 
            <div className="animated fadeIn p-t3 p-lr1">
                <div className="col-lg-12 col-md-12 col-sm-12 border p-t1 frame-bg m-b1">
                <div className="col-lg-12 col-md-12 col-sm-12 m-b"> 
                    <p className="p-t1 font m-b">Projected Claims</p>
                    <MixedLineBar />
                </div>
                <div className="col-lg-12 col-md-12 col-sm-12 displayFlex m-b1"> 
                  <div className="col-lg-6 col-md-12 col-sm-12 border-top">
                    <p className="p-t1 font">Projected AC Claims</p>
                    <MixedLineBar2 />
                  </div>
                  <div className="col-lg-6 col-md-12 col-sm-12 border-top ml-4">
                    <p className="p-t1 font">Projected Brake Claims</p>
                    <MixedLineBar3 />
                  </div>
                </div>
                </div> 
            </div>    
        );
    }
}
 

export default ProjectedClaims;