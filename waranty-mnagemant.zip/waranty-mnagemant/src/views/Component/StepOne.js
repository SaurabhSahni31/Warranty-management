import React, { Component } from "react";
import { Row, Col, Label, Button, Input } from "reactstrap";
import axios from "axios";

class StepOne extends Component {
  constructor(props) {
    super(props);
    this.state = {
      productDetail: []
    };
  }
  continue = e => {
    this.props.nextStep();
  };

  //   componentDidMount(){
  //     axios.get('http://www.json-generator.com/api/json/get/bVkYwQaoXS?indent=2')
  //     .then(json => console.log(json.data.productDetails[0].productName))

  //   }
  //  componentDidMount(){
  //    axios.get('http://www.json-generator.com/api/json/get/bVWcQjhPTm?indent=2')
  //     .then(json => json.data.productDetails.map(productDetail => (
  //       {
  //         product: `${productDetail.productName}`,
  //      })))

  //   }
  render() {
    const { productDetail } = this.state;
    return (
      <div className="Card">
        <div className="header">PRODUCT DETAILS</div>
        <Row className="mt-1">
          <Col sm="6">
            <Label className="modal-title-cmp">Product Name</Label>
            <Input></Input>
          </Col>
          <Col sm="6">
            <Label className="modal-title-cmp">Product Details</Label>
            <Input></Input>
          </Col>
          <Col sm="2" lg="2">
            <Button
              type="button"
              color="success"
              className="p-lr2 cmp-floatLeft"
              onClick={this.continue}
            >
              Next
            </Button>

            <Button
              type="button"
              color="success"
              className="p-lr2 cmp-floatLeft"
              onClick={this.back}
            >
              Previous
            </Button>
          </Col>
        </Row>
      </div>
    );
  }
}

export default StepOne;
