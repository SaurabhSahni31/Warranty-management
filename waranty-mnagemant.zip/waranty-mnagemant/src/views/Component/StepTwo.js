import React, { Component } from "react";
import { Row, Col, Button, Input, Label } from "reactstrap";
import ClaimSeverity from "../../DropDownMenu/ClaimSeverity";

class StepTwo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedFile: null
    };
  }
  continue = e => {
    this.props.nextStep();
  };
  back = e => {
    this.props.prevStep();
  };
  onChangeHandler=event=>{
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0,
    })
  }
  render() {
    const { productsData } = this.state;
    console.log(productsData);
    return (
      <div>
        <h5>CREATE CLAIM</h5>
        <Row>
          <Col sm="6">
            <ClaimSeverity />
          </Col>
         </Row>
          <Row>
            <Col sm="6">
              <Label className="modal-title-cmp">Caim Reason</Label>
              <Input type="textarea" className="modal-input-cmp pl-10"></Input>
            </Col>
          </Row>
          <Row>
          <Col sm="2" lg="2">
            <Button
              type="button"
              color="success"
              className="p-lr2 cmp-floatLeft"
              onClick={this.continue}
            >
              Submit
            </Button>

            <Button
              type="button"
              color="success"
              className="p-lr2 cmp-floatLeft"
              onClick={this.back}
            >
              Previous
            </Button>
          </Col>
        </Row>
      </div>
    );
  }
}
export default StepTwo;
