import React, { Component } from "react";
import StepOne from "../Component/StepOne";
import StepTwo from "../Component/StepTwo";
import StepThree from "../Component/StepThree";

export class CreateClaim extends Component {
  constructor(props) {
    super(props);
    this.state = {
      step: 1
    };
  }
  togglePopup() {
    this.setState({
      showPopup: !this.state.showPopup
    });
  }

  nextStep = () => {
    const { step } = this.state;
    this.setState({
      step: step + 1
    });
  };

  prevStep = () => {
    const { step } = this.state;
    this.setState({
      step: step - 1
    });
  };

  renderSwitch(step) {
    switch (step) {
      case 1:
        return <StepOne nextStep={this.nextStep} />;
      case 2:
        return <StepTwo nextStep={this.nextStep} prevStep={this.prevStep} />;
      case 3:
        return <StepThree nextStep={this.nextStep} prevStep={this.prevStep} />;
    }
  }
  render() {
    const { step } = this.state;
    return <div>{this.renderSwitch(step)}</div>;
  }
}

export default CreateClaim;
