import React, { Component } from 'react';
import { Col, Row, Button, InputGroupAddon, Table, CardHeader, FormGroup, Input, Label, Modal, ModalBody, CardBody, InputGroup, Card } from 'reactstrap';
import '../../StyleSheet/Default.css';
var data = require('../Repair-order/Repair-order.json')

class RepairOrder extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            modal1: false,
            repairData: data,
            model:"",
            productserialno:"",
            complaint:"",
            repairdescription:"",
            customername:"",
            customerlocation:""
        }
        this.toggle = this.toggle.bind(this);
    }
    toggle() {
        this.setState({
            modal: !this.state.modal,
        });
    }
    toggle1(Id) {
        this.setState({
            modal1: !this.state.modal1,
            repairId: Id
        });
    }
    model(value) {
        this.setState({
          model: value,
        });
      }
    productserialno(value)
      {
          this.setState({
              productserialno:value,
          });
      }
      complaint(value)
      {
          this.setState({
              complaint:value,
          });
      }
      repairdescription(value)
      {
          this.setState({
              repairdescription:value,
          });
      }
      customername(value)
      {
          this.setState({
              customername:value,
          });
      }
      customerlocation(value)
      {
          this.setState({
              customerlocation:value,
          });
      }
      createRepairorder()
      {
        
        if (this.state.model !== " " && this.state.productSerialNo !== " ") {
            var requestBody = {
                "id":Math.floor(Math.random()*100000),
                "productSerialNo":this.state.productserialno,
                "model":this.state.model,
                "complaint":this.state.complaint,
                "repairDescription":this.state.repairdescription,
                "customer":this.state.customername,
                "customerLocation":this.state.customerlocation,
                "notificationNo":"1245658965",
                "warrantyEndDate":"Oct 28, 2019",
                "warrantyStatus":"Under Warranty",
                   
            }
            this.state.repairData.unshift(requestBody);
         
        }
        else{
            alert("Please select Mandatory value")
        }  
        this.setState({
            modal: false,
          });
      }
      


    render() {
        var repairForModal = [];
        if (this.state.repairId) {
            this.state.repairData.map(repair => {
                if (repair.id === this.state.repairId) {
                    repairForModal.push(repair);
                }
            })
        }
        return (
            <div className="animated fadeIn p-lr1">
                 
                {/* Modal for creating a Repair-Order*/}
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        <Card className="pl-7 pr-7">
                            <CardBody>
                                <h4 className="mb-2">CREATE REPAIR ORDER</h4>
                                <Row className="mt-1">
                                    <Col md="6">
                                        <Label className="modal-title-cmp">Model</Label>
                                        <Input type="text" onChange={(e) => this.model(`${e.target.value}`)} className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                    <Col md="6">
                                        <Label className="modal-title-cmp">Product Serial Number</Label>
                                        <Input type="text" onChange={(e) => this.productserialno(`${e.target.value}`)} className="modal-input-cmp pl-10" ></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Complaint</Label>
                                        <Input type="text" onChange={(e) => this.complaint(`${e.target.value}`)} className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Repair Description</Label>
                                        <Input type="text" onChange={(e) => this.repairdescription(`${e.target.value}`)} className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1" >
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Customer Name</Label>
                                        <Input type="text" onChange={(e) => this.customername(`${e.target.value}`)} className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Customer Location</Label>
                                        <Input type="text" onChange={(e) => this.customerlocation(`${e.target.value}`)} className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Check In Date</Label>
                                        <Input type="date" className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Repair Location</Label>
                                        <Input type="text" className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Estimated Date</Label>
                                        <Input type="date" className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                    <Col sm="6">
                                        <Label className="modal-title-cmp">Estimated Time</Label>
                                        <Input type="time" className="modal-input-cmp pl-10"></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label className="modal-title-cmp">Problem Descripton</Label>
                                            <Input type="textarea" className="modal-input-cmp pl-10"></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="mt-3 mb-2">
                                    <Col sm="6">
                                        <Button onClick={this.toggle}  outline color="danger" className="pl-3 pr-3 " >CANCEL</Button>
                                    </Col>
                                    <Col sm="6">
                                        <Button  onClick={this.createRepairorder.bind(this)} className="pl-3 pr-3 cmp-floatRight btn btn-success" >CREATE</Button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </ModalBody>
                </Modal>

                {/* Modal for viewing the order list */}
                <Modal isOpen={this.state.modal1} toggle={this.toggle1.bind(this)} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        {repairForModal.map(repair =>
                            <Card>
                                <CardBody>
                                    <Row ><h3 className="ml-2">ID-{repair.notificationNo}, {repair.complaint}</h3></Row>
                                    <Row className="mt-2">
                                        <Col sm="1"></Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Product Serial No.</Label>
                                            <Card className="modal-input-cmp pl-10"><Label className="fs-1 p-l10 p-t5px">{repair.productSerialNo}</Label></Card>
                                        </Col>
                                        <Col sm="2"></Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Model</Label>
                                            <Card className="modal-input-cmp pl-10"><Label className="fs-1 p-l10 p-t5px">{repair.model}</Label></Card>
                                        </Col>
                                        <Col sm="1"></Col>
                                    </Row>
                                    <Row>
                                        <Col sm="1"></Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Warranty End Date</Label>
                                            <Card className="modal-input-cmp pl-10"><Label className="fs-1 p-l10 p-t5px">{repair.warrantyEndDate}</Label></Card>
                                        </Col>
                                        <Col sm="2"></Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Warranty Status</Label>
                                            <Card className="modal-input-cmp pl-10"><Label className="fs-1 p-l10 p-t5px">{repair.warrantyStatus}</Label></Card>
                                        </Col>
                                        <Col sm="1"></Col>
                                    </Row>
                                    <Row>
                                        <Col sm="1"></Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Customer Name</Label>
                                            <Card className="modal-input-cmp pl-10"><Label className="fs-1 p-l10 p-t5px">{repair.customer}</Label></Card>
                                        </Col>
                                        <Col sm="2"></Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Customer Location</Label>
                                            <Card className="modal-input-cmp pl-10"><Label className="fs-1 p-l10 p-t5px">{repair.customerLocation}</Label></Card>
                                        </Col>
                                        <Col sm="1"></Col>
                                    </Row>
                                    <Row className="mt-2">
                                        <Col sm="12">
                                            <Table responsive hover bordered size="lg" >
                                                <thead>
                                                    <tr>
                                                        <th>NOTIFICATION No.</th>
                                                        <th>REPAIR ORDER DATE</th>
                                                        <th>REPAIR DESCRIPTION</th>
                                                        <th>REPLACED PART</th>
                                                        <th>LABOUR HOURS</th>
                                                        <th>LABOUR COST</th>
                                                        <th>RETURN REQUEST</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {repair.repairHistory.map(repairDetail =>

                                                        <tr>
                                                            <td>
                                                                <p>{repairDetail.notification}</p>
                                                            </td>
                                                            <td className="center">
                                                                <p>{repairDetail.repairOrderDate}</p>
                                                            </td>
                                                            <td>
                                                                <p>{repairDetail.repairDetails}</p>
                                                            </td>
                                                            <td>
                                                                <p>{repairDetail.replacedPart}</p>
                                                            </td>
                                                            <td className="center">
                                                                <p>{repairDetail.labourHours} hrs</p>
                                                            </td>
                                                            <td className="center">
                                                                <p>${repairDetail.labourCost} </p>
                                                            </td>
                                                            <td>
                                                                <p>{repairDetail.returnRequest}</p>
                                                            </td>
                                                        </tr>

                                                    )}
                                                </tbody>
                                            </Table>
                                        </Col>
                                    </Row>
                                    <Row className="mt-3 mb-2">
                                        <Col sm="12">
                                            <Button onClick={this.toggle1.bind(this)}  outline color="danger" className="pl-3 pr-3 fr" >CLOSE</Button>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        )}

                    </ModalBody>
                </Modal>

                <Row className="display-block cmp-floatRight m-b-5px">
                    <div >
                      <Button onClick={this.toggle} type="button" color="primary"  className="">CREATE REPAIR ORDER</Button>
                    </div>
                </Row>
                <Row className="display-block">
              
                <Card className="col-12 padding0">
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">REPAIR ORDER LIST</h5>
                                    </Col> 
                                    <Col className="cmp-pr-0">
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="cmp-searchBar-width"  placeholder="Search for Repair Order ID...." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>

                                    <Table responsive striped size="lg" >
                                        <thead>
                                            <tr>
                                                <th>NOTIFICATION NO.</th>
                                                <th>MODEL & COMPLAINT</th>
                                                <th>REPAIR DESCRIPTION</th>
                                                <th>CUSTOMER</th>
                                                <th className="center">WARRANTY END DATE</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.state.repairData.map(repair =>
                                                <tr>
                                                    <td>
                                                        <p>{repair.notificationNo}</p>
                                                    </td>
                                                    <td>
                                                        <p className="title-cmp">{repair.model}</p>
                                                        <p>{repair.complaint}</p>
                                                    </td>
                                                  
                                                    <td>
                                                        <p className="cmp-mw-18 description-cmp">{repair.repairDescription}</p>
                                                    </td>
                                                    <td>
                                                        <p>{repair.customer}</p>
                                                    </td>
                                                    <td className="center">
                                                        <p className="date-cmp">{repair.warrantyEndDate}</p>
                                                    </td>
                                                    <td><Button onClick={this.toggle1.bind(this, repair.id)} className="btn btn-sm btn-info">View</Button></td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </Table>
                            </CardBody>
                      </Card>
                   </Row>     
            </div>
        );
    }
}

export default RepairOrder;