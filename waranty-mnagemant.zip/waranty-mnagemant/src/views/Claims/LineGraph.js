import React, {Component} from 'react';
import { Line } from 'react-chartjs-2';

const data = {
  labels: ['', '', '', 'January', '', '', '', 'Feburary', '', '', '', 'March'],
  datasets: [
    {
      label: 'Total Claims',
      fill: false,
      backgroundColor: 'rgba(75,192,192,0.4)',
      borderColor: 'rgba(75,192,192,1)',
      borderDash: [],
      borderJoinStyle: 'miter',
      pointBorderColor: 'rgba(75,192,192,1)',
      pointBackgroundColor: '#fff',
      pointBorderWidth: 1,
      pointHoverRadius: 4,
      pointHoverBackgroundColor: 'rgba(75,192,192,1)',
      pointHoverBorderColor: 'rgba(220,220,220,1)',
      pointHoverBorderWidth: 2,
      pointRadius: 5,
      pointHitRadius: 10,
      data: [3, 6, 5, 8, 11, 5, 8, 6, 2, 13, 10, 4]
    }
  ]};
  var dataOptions= {
    scales: {
        xAxes: [{
            gridLines: {
                display:false
            },
            scaleLabel: {
              display: true,
              labelString: '2019'
            }
        }],
        yAxes: [{
            gridLines: {
                display:false
            },
            ticks: {
              min: 0,
              max: 25,
              stepSize: 5
            },
            scaleLabel: {
              display: true,
              labelString: 'No. of claims'
            }
        }]
  }};


export default class LineDemo extends Component {
  render() {
    return (
      <div className="m-t1">
        <Line data={data} options={dataOptions} />
      </div>
    );
  }
}