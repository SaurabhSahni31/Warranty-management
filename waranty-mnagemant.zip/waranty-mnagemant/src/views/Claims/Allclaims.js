import React, { Component } from 'react';
import { Button, Col, FormGroup, Row, InputGroup, Input, Progress, CardHeader, InputGroupAddon, Modal, ModalBody, Label, Card, CardBody, Table, Pagination, PaginationItem, PaginationLink } from 'reactstrap';
import '../../StyleSheet/Default.css'
var data = require('../Claims/Claims.json')

class Allclaims extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      modal1:false,
      claimsData: data
    }
    this.toggle1 = this.toggle1.bind(this);

    //this.toggle = this.toggle.bind(this);
  }
  toggle1() {
    this.setState({
      modal1: !this.state.modal1,
    });
  }
  toggle(Id) {
    console.log("Selected Array Id", Id);
    this.setState({
      modal: !this.state.modal,
      claimId: Id
    });
  }
  problemDescription(value){
    this.setState({
      problemDescription:value
    })
   }
  render() {
    var claimsForModal = [];
    if (this.state.claimId) {
      console.log("this.state.claimId this.state.claimId", this.state.claimId);
      this.state.claimsData.map(claim => {
        if (claim.id === this.state.claimId) {
          claimsForModal.push(claim);
        }
      });
    }

    console.log("claimsForModal", claimsForModal);

    //  console.log(this.state.claimsData);
    return (
      <div className="animated fadeIn">
                {/**Modal for Viewing Claims */}
        <Modal isOpen={this.state.modal} toggle={this.toggle.bind(this)} className={'modal-xl ' + this.props.className}>
          <ModalBody>
            {claimsForModal.map(claims =>
              <Card>
                <CardBody>
                  <h4 className="m-b2">{claims.id},{claims.claims} </h4>
                  <Row>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Claim Type</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.claims}</Label></Card>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Status</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.status}</Label></Card>
                    </Col>
                    <Col sm="6">
                      <Label className="modal-title-cmp">Percentage Completed</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.percentage}</Label></Card>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm="3">
                      <FormGroup>
                        <Label className="modal-title-cmp">Estimated Date</Label>
                        <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.estimatedDate}</Label></Card>
                      </FormGroup>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Reference Date</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.createdOn}</Label></Card>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Last Update Date</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.lastUpdated}</Label></Card>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Updated By</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.updatedBy}</Label></Card>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm="3">
                      <FormGroup>
                        <Label className="modal-title-cmp">Author No.</Label>
                        <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.authorNo}</Label></Card>
                      </FormGroup>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Name</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.name}</Label></Card>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Partner</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.partner}</Label></Card>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Material</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1">{claims.material}</Label></Card>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm="3">
                      <FormGroup>
                        <Label className="modal-title-cmp">Total Amount</Label>
                        <InputGroup>
                        <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{claims.totalAmount}</Label></Card>
                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                      </InputGroup>
                      </FormGroup>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Total Material</Label>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{claims.totalMaterial}</Label></Card>
                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                      </InputGroup>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Total Labour Value</Label>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{claims.totalLabour}</Label></Card>
                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                      </InputGroup>
                    </Col>
                    <Col sm="3">
                      <Label className="modal-title-cmp">Total External Service</Label>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{claims.totalExternal}</Label></Card>
                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                      </InputGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col lg="12">
                    <FormGroup>
                      <Label  className="modal-title-cmp">Problem description</Label>
                      <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{claims.problemDescription}</Label></Card>
                    </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col sm="12">
                      <FormGroup>
                        <Label className="modal-title-cmp">Required Action</Label>
                        <InputGroup>
                          <Input id="appendedInput" size="16" type="file" />
                        </InputGroup>
                        <Label  className="txt-cmp-danger">Attach image of the defective part</Label>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row className="m-t3 m-b2">
                    <Col sm="6">
                      <Button type="button" color="danger" className="p-lr3" >DELETE</Button>
                    </Col>
                    <Col sm="4" >
                      <Button onClick={this.toggle.bind(this)} type="button" outline color="danger" className="p-lr3 cmp-floatRight" >CANCEL</Button>
                    </Col>
                    <Col sm="2">
                      <Button type="button" color="success" className="p-lr3 cmp-floatRight" >REGISTER</Button>
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            )}
          </ModalBody>
        </Modal>

        {/*Modal for creating a claim */}
            <Modal isOpen={this.state.modal1} toggle={this.toggle1} className={'modal-xl '+ this.props.className}>
                  <ModalBody>
                      <Card className="p-lr6">
                        <CardBody>
                            <h4 className="m-b2">CREATE CLAIM</h4>
                            <Row className="m-t1">
                              <Col sm="3">
                                  <Label className="modal-title-cmp">Claim Type</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>
                              </Col>
                              <Col sm="3">
                                  <Label  className="modal-title-cmp">Reference Date</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>   
                              </Col>
                              <Col sm="3">
                                  <Label  className="modal-title-cmp">Partner</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>
                              </Col>
                              <Col sm="3">
                                  <Label  className="modal-title-cmp">Author Number</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>   
                              </Col>
                            </Row>
                            <Row className="p-t1">
                              <Col sm="3">
                                  <Label  className="modal-title-cmp">Material</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>
                              </Col>
                              <Col sm="3">
                                  <Label  className="modal-title-cmp">Material Amount</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>   
                              </Col>
                              <Col sm="3">
                                  <Label className="modal-title-cmp">Labour Amount</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>
                              </Col>
                              <Col sm="3">
                                  <Label className="modal-title-cmp">External Service</Label>
                                  <Input type="text" className="modal-input-cmp p-l10"></Input>   
                              </Col>
                            </Row>
                            <Row>
                              <Col lg="12">
                                <FormGroup>
                                  <Label  className="modal-title-cmp">Problem description</Label>
                                  <Input type="text" onChange={(e) => this.problemDescription(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                                  </FormGroup>
                              </Col>
                            </Row>
                            
                            <Row className="p-t3 m-b2">
                                <Col sm="7" lg="7">
                                      <Button type="button"  color="danger" className="p-lr2" >DELETE</Button>
                                </Col>
                                <Col sm="3" lg="3" >
                                      <Button onClick={this.toggle1} type="button" outline  color="danger" className="p-lr2 cmp-floatRight" >CANCEL</Button>
                                </Col>
                                <Col sm="2" lg="2">
                                      <Button type="button"  color="success" className="p-lr2 cmp-floatRight" >CREATE</Button>
                                </Col>
                            </Row>
                        </CardBody>
                      </Card>
                  </ModalBody>
              </Modal>

              <Row className="display-block cmp-floatRight m-b-5px">
                    <div >
                    <Button onClick={this.toggle1} type="button" color="primary" className="createbutton">CREATE CLAIM</Button>
                    </div>
                </Row>
                <Row className="display-block">
                <Card className="col-12 p-0">
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">CLAIM LIST</h5>
                                    </Col> 
                                    <Col>
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="cmp-searchBar-width"  placeholder="Search for Claim ID...." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>
              <Table responsive striped size="lg" >
                <thead>
                  <tr>
                    <th>CLAIMS</th>
                    <th className="center">STATUS</th>
                    <th className="center p-r4"> DATE</th>
                    <th>DESCRIPTION</th>
                    <th>  </th>
                  </tr>
                </thead>
                <tbody>
                  {this.state.claimsData.map(claims =>
                    <tr>
                    <td>
                    <div>
                      <p className="title-cmp padding0 margin0">{claims.claims}, <Label className="title-cmp margin0 cmp-checkColor">{claims.oem}</Label> </p>
                    </div>
                      
                      <p className="description-cmp cmp-mw-18">{claims.problemDescription}</p>
                    </td>
           
                    <td>
                    <Row >
                        <Col className="displayFlex title-cmp" sm="3">{claims.percentage}%</Col>
                        <Col sm="9" className="center">
                           <p className="cmp-border0">
                      
                        {claims.percentage < 25 ? <Label className="txt-cmp-danger cmp-smallFont-Bold">Over Due</Label> : null}
                        {(claims.percentage >= 25) && (claims.percentage < 60) ? <Label className="txt-cmp-warning cmp-smallFont-Bold" >Delay</Label> : null}
                        {(claims.percentage >= 60) && (claims.percentage <= 99) ? <Label className="txt-cmp-info cmp-smallFont-Bold">On Track</Label> : null}
                        {claims.percentage === 100 ?<Label className="txt-cmp-success cmp-smallFont-Bold">Completed</Label> : null}                      
                        
                        </p></Col>
                    </Row>             
                    <Row>

                        {claims.percentage < 25 ? <Col><Progress value={claims.percentage} color="danger" className="mb-3" className="progress-cmp" /></Col> : null}
                        {(claims.percentage >= 25) && (claims.percentage < 60) ? <Col><Progress value={claims.percentage} color="warning" className="mb-3" className="progress-cmp" /></Col> : null}
                        {(claims.percentage >= 60) && (claims.percentage < 100) ? <Col><Progress value={claims.percentage} color="info" className="mb-3" className="progress-cmp" /></Col> : null}
                        {claims.percentage > 99 ? <Col><Progress value={claims.percentage} color="success" className="mb-3" className="progress-cmp" /></Col> : null}

                    </Row>
                    </td>
                    <td>
                        <Row>
                        <Col>
                          <p className="cmp-checkColor m-0 cmp-smallFont">Created on: {claims.createdOn}</p> 
                          <p className="cmp-smallFont-Bold">Estimated on: {claims.estimatedDate}</p></Col>                   
                        </Row>
                    </td>
                        <td>
                            <p className=" m-0">{claims.action}</p>
                            <p className="text-muted small m-0">Last Updated: {claims.lastUpdated}</p>
                        </td>
                        <td><Button type="button" size="sm" color="info" onClick={this.toggle.bind(this, claims.id)}>View</Button></td>
                    </tr> 
                    )}   
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Row>

          <Pagination className="pagin">
            <PaginationItem>
              <PaginationLink previous tag="button"></PaginationLink>
            </PaginationItem>
            <PaginationItem active>
              <PaginationLink tag="button">1</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink tag="button">2</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink tag="button">3</PaginationLink>
            </PaginationItem>
            <PaginationItem>
              <PaginationLink next tag="button"></PaginationLink>
            </PaginationItem>
          </Pagination>

   
      </div>
    );
  }
}

export default Allclaims;
