import React, { Component } from 'react';

class ProductList extends Component {
    
    render() { 
        return (  
            <>
                <div>
                    <p className="cmp-title cmp-m0 cmp-p0">{this.props.productName}</p>
                </div>
                <div className="cmp-describe cmp-mw-20 cmp-m0">              
                    {this.props.productNo}
                    {this.props.claimType}
                    {this.props.oem}
                    
                </div>
            </>

            );
        }
    }
export default ProductList;