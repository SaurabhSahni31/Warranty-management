import React, { Component } from 'react';
import { Button, Card, InputGroupAddon, Row,Table, CardHeader, CardBody, FormGroup, InputGroup, Col, Modal, ModalBody, Label,Input } from 'reactstrap';
import '../../StyleSheet/Default.css';
var data = require('../Returns/Returns.json')

class Returns extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal:false,
            modal1:false,
            returnsData:data,
            productSerialNo:"",
            venderNo:"",
            claimNo:"",
            itemNo:"",
            orderQty:"",
            netValue:"",
            returnMaterial:"",
            returnReason:"",
            status:"",
            inspectionCode:"",
            refundType:"",
            refundControl:""
        }
        this.toggle= this.toggle.bind(this);
    }
    toggle() {
        this.setState({
            modal: !this.state.modal,
        });
    }
    toggle1(Id) {
        this.setState({
            modal1: !this.state.modal1,
            returnsId:Id
        });
    }
    productSerialNo(value){
        this.setState({
            productSerialNo:value
        })
    }
    venderNo(value){
        this.setState({
            venderNo:value
        })
    }
    claimNo(value){
        this.setState({
            claimNo:value
        })
    }
    itemNo(value){
        this.setState({
            itemNo:value
        })
    }
    orderQty(value){
        this.setState({
            orderQty:value
        })
    }
    netValue(value){
        this.setState({
            netValue:value
        })
    }
    returnMaterial(value){
        this.setState({
            returnMaterial:value
        })
    }
    returnReason(value){
        this.setState({
            returnReason:value
        })
    }
    status(value){
        this.setState({
            status:value
        })
    }
    inspectionCode(value){
        this.setState({
            inspectionCode:value
        })
    }
    refundType(value){
        this.setState({
            refundType:value
        })
    }
    refundControl(value){
        this.setState({
            refundControl:value
        })
    }
    createReturns(){
        if(this.state.productSerialNo!=="" && this.state.returnMaterial!==""){
            var requestBody={
                "productSerialNo":this.state.productSerialNo,
                "venderNo":this.state.venderNo,
                "claimNo":this.state.claimNo,
                "itemNo":this.state.itemNo,
                "orderQty":this.state.orderQty,
                "netValue":this.state.netValue,
                "returnMaterial":this.state.returnMaterial,
                "returnReason":this.state.returnReason,
                "status":this.state.status,
                "inspectionCode":this.state.inspectionCode,
                "refundType":this.state.refundType,
                "refundControl":this.state.refundControl,
                "returnOrderNo":Math.floor(Math.random()*100000),
                "batchNo":"ANH8125",
                "lastUpdated":"July 28, 2019"
                 
            }
            this.state.returnsData.unshift(requestBody);
        }
        else{
            alert("Fill the Mandatory value");
        }
        this.setState({
            modal:false,
        })
    }
    render() {
        var returnsForModal=[];
        if(this.state.returnsId){
            this.state.returnsData.map(returns=> {
                if(returns.claimNo ===this.state.returnsId){
                    returnsForModal.push(returns);
                }
            })
        }
        return (
            <div class="animated fadedIn p-lr1">
                {/* Modal for creating a Return Request*/}
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        <Card className="p-l-7 p-r-7">
                            <CardBody>
                                <h4 className="m-b-2">CREATE RETURN ORDER</h4>
                                <Row className="mt-1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Product Serial Number</Label>
                                        <Input type="text"onChange={(e) => this.productSerialNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Vendor No.</Label>
                                        <Input type="text" onChange={(e) => this.venderNo(`${e.target.value}`)}className="modal-input-cmp p-l10" ></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Claim No.</Label>
                                        <Input type="text" onChange={(e) => this.claimNo(`${e.target.value}`)}className="modal-input-cmp p-l10" ></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Item No.</Label>
                                        <Input type="text"onChange={(e) => this.itemNo(`${e.target.value}`)} className="modal-input-cmp p-l10" ></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Order Quantity</Label>
                                        <Input type="text" onChange={(e) => this.orderQty(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Net Value</Label>
                                        <Input type="text"onChange={(e) => this.netValue(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Return Material</Label>
                                        <Input type="text"onChange={(e) => this.returnMaterial(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Return Reason</Label>
                                        <Input type="text" onChange={(e) => this.returnReason(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Status</Label>
                                        <Input type="text" onChange={(e) => this.status(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Inspection Code</Label>
                                        <Input type="text" onChange={(e) => this.inspectionCode(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Refund Type</Label>
                                        <Input type="text" onChange={(e) => this.refundType(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Refund Control</Label>
                                        <Input type="text" onChange={(e) => this.refundControl(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                
                                <Row className="mt-3 mb-2">
                                    <Col md="6">
                                        <Button onClick={this.toggle} type="button" outline color="danger" className="pl-3 pr-3" >CANCEL</Button>
                                    </Col>
                                    <Col md="6">
                                        <Button  color="success" onClick={this.createReturns.bind(this)} className="pl-3 pr-3 cmp-floatRight" >CREATE</Button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </ModalBody>
                </Modal>

                {/* Modal for Viewing Return Request */}
                <Modal isOpen={this.state.modal1} toggle={this.toggle1.bind(this)} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        {returnsForModal.map(returns =>
                          
                            <Card>
                                <CardBody>
                                    <Row ><h3 className="ml-2">ID-{returns.claimNo}</h3></Row>
                                    <Row className="mt-2">
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Return Order No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.returnOrderNo}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Product Serial Number</Label>
                                            <Card className="modal-input-cmp p-l10"><Label >{returns.productSerialNo}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Order Quantity</Label>
                                            <Card className="modal-input-cmp p-l10"><Label >{returns.orderQty}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Net Value</Label>
                                            <Card className="modal-input-cmp p-l10"><Label >{returns.netValue}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Item No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.itemNo}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Batch No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.batchNo}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Return Material</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.returnMaterial}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Return Reason</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.returnReason}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Status</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.status}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Inspection Code</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.inspectionCode}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Refund Type</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.refundType}</Label></Card>
                                        </Col>
                                        <Col md="3">
                                            <Label className="modal-title-cmp">Refund Control</Label>
                                            <Card className="modal-input-cmp p-l10"><Label>{returns.refundControl}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row className="mt-3 mb-2">
                                        <Col md="12">
                                            <Button onClick={this.toggle1.bind(this, returns.claimNo)} type="button" outline color="danger" style={{ paddingLeft: '50px', paddingRight: '50px', float: 'right' }} >CLOSE</Button>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                              )}
                    </ModalBody>
                </Modal>
                <Row className="display-block cmp-floatRight m-b-5px">
                    <div >
                        <Button onClick={this.toggle}  color="primary" >CREATE RETURN REQUEST</Button>
                    </div>
                </Row>
                <Row className="display-block">
              
                <Card className="col-12 p-0">
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">RETURNS LIST</h5>
                                    </Col> 
                                    <Col className="cmp-pr-0">
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="cmp-searchBar-width" placeholder="Search for Returns ID.." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>
                            <Table responsive striped size="lg" >
                            <thead>
                                <tr>
                                    <th>RETURN ORDER NO.</th>
                                    <th>CLAIM NO.</th>
                                    <th>PRODUCT SERIAL NUMBER</th>
                                    <th className="center">VENDOR NO.</th>
                                    <th>RETURN MATERIAL</th>
                                    <th>STATUS</th>
                                    <th className="center">LAST UPDATED</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.returnsData.map(returns=>
                                   
                                    <tr>
                                        <td>
                                            <p> {returns.returnOrderNo}</p>
                                        </td>
                                        <td>
                                            <p>{returns.claimNo}</p>
                                        </td>
                                        <td>
                                            <p>{returns.productSerialNo}</p>
                                        </td>
                                        <td className="center">
                                            <p>{returns.venderNo}</p>
                                        </td>
                                        <td>
                                            <p>{returns.returnMaterial}</p>
                                        </td>
                                        <td>
                                            <p>{returns.status} </p>
                                        </td>
                                        <td className="center">
                                            <p>{returns.lastUpdated}</p>
                                        </td>
                                        <td><Button onClick={this.toggle1.bind(this,returns.claimNo)} className="btn btn-sm btn-info">View</Button></td>
                                    </tr>
                               )}
                            </tbody>
                        </Table>
                            </CardBody>
                        </Card>
                  
                </Row>

            </div>
        );
    }
}

export default Returns;