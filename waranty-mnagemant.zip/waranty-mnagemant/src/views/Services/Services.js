import React, { Component } from 'react';
import {  Doughnut } from 'react-chartjs-2';
import {  Row,Col, Card, CardHeader, FormGroup,  Modal, ModalBody,InputGroupAddon, Label, Input, InputGroup, Button, Table, Progress, CardBody } from 'reactstrap';
import '../../StyleSheet/Default.css'
import { GiGears } from "react-icons/gi";
var data=require('../Services/Services.json')
const Moment = require('moment-timezone');

const doughnut = {
  labels: [
    'Pending',
    'Closed',
    'Claimed',
  ],
  datasets: [
    {
      data: [5, 10, 3],
      backgroundColor: [
        '#FFCE56',
        '#4dbd74',
        '#0b6623',
      ],
      hoverBackgroundColor: [
        '#FFCE56',
        '#4dbd74',
        '#0b6623',
      ],
    }],
    options: {
        elements: {
            center: {
            text: 'Desktop',
            color: '#36A2EB', //Default black
            fontStyle: 'Helvetica', //Default Arial
            sidePadding: 15 //Default 20 (as a percentage)
          }
        }
      }
}; 

class Services extends Component {
  constructor(props) {
    super(props);
    this.state = { 
      Modal: false,
      Modal1: false,
      serviceData:data,
      serviceType:"",
      serviceDescription:"",
      breakDownDate:"",
      breakDownTime:"",
      material:"",
      materialDescription:"",
      author:"",
      name:"",
      problemDescription:""
     }
    this.handlePageChange = this.handlePageChange.bind(this);
    this.toggle = this.toggle.bind(this); 
    this.toggle1= this.toggle1.bind(this); 

}
  handlePageChange() {
    window.location.hash = "/Services/Allservice";
  }
  toggle() {
    this.setState({
      modal: !this.state.modal,
       });
    }
    toggle1(Id) {
        this.setState({
            modal1: !this.state.modal1,
            serviceId:Id
        });
    }
    serviceType(value){
        this.setState({
            serviceType:value
        })
    }
    description(value){
        this.setState({
            description:value
        })
    }
    breakDownDate(value){
        this.setState({
            breakDownDate:value
        })
    }
    breakDownTime(value){
        this.setState({
            breakDownTime:value
        })
    }
    material(value){
        this.setState({
            material:value
        })
    }
    materialDescription(value){
        this.setState({
            materialDescription:value
        })
    }
    author(value){
        this.setState({
            author:value
        })
    }
    name(value){
        this.setState({
            name:value
        })
    }
    problemDescription(value){
        this.setState({
            problemDescription:value
        })
    }
    vin(value){
        this.setState({
            vin:value
        })
    }
    breakDownDate(value){
        this.setState({
            breakDownDate:value
        })
    }
    breakDownTime(value){
        this.setState({
            breakDownTime:value
        })
    }
    createServices(){
        if(this.state.serviceType!=="" && this.state.name!==""){
            var requestBody={
                "id":Math.floor(Math.random()*100000),
                "service": this.state.serviceType,
                "description": this.state.description,
                "breakDownDate":this.state.breakDownDate,
                "breakDownTime":this.state.breakDownTime,
                "material":this.state.material,
                "materialDescription": this.state.materialDescription,
                "author":this.state.author,
                "name":this.state.name,
                "vin":this.state.vin,
                "problemDescription":this.state.problemDescription,
                "percentage": "0",
                "status": "New",
                "duration": "Aug 22, 2017 - Dec 10,2017",
                "lastUpdated":"-",
                "serviceDetail": "Assigned",
                "StartDate": Moment().format("MMM DD, YYYY"),
                "EndDate": Moment().add(5, 'days').format("MMM DD, YYYY"),
                "updatedBy": "Classic motors",
                "breakDownDate": this.state.breakDownDate,
                "breakDownTime": this.state.breakDownTime,
                "totalAmount": "200.00",
                "totalMaterial": "20.00",
                "totalLabour": "150.00",
                "totalExternal": "30.00"
            }
            this.state.serviceData.unshift(requestBody);
        }
        else{
            alert("Fill the Mandatory Value");
        }
        this.setState({
            modal:false,
        })
    }
    

  render() {

      var serviceForModal=[];
      if(this.state.serviceId)
      {
        this.state.serviceData.map(service =>{
            if(service.id===this.state.serviceId)
            {serviceForModal.push(service)}
        });
      }
    return (
  
    <div className="animated fadeIn p-lr1 p-0">
        <div className="float-right">
            <Button onClick={this.toggle} type="button" color="primary" className="createbutton" className="m-l1 m-b-5px">CREATE SERVICE</Button>
        </div>
         
        {/* Modal for Create Service */}
        <Modal  isOpen={this.state.modal} toggle={this.toggle} className={'modal-xl '+ this.props.className}>
            <ModalBody>
                <Card className="p-lr3">
                  <CardBody>
                    <h4 className="m-b3">CREATE SERVICE</h4>
                    <Row className="m-t1">
                    <Col sm="6" lg="3">
                        <Label className="modal-title-cmp">Service Type</Label>
                        <Input type="text" onChange={(e) => this.serviceType(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                    </Col>
                    <Col sm="6" lg="3">
                        <Label className="modal-title-cmp">VIN</Label>
                        <Input type="text" onChange={(e) => this.vin(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>  
                    </Col>
                    <Col sm="6" lg="3">
                        <Label className="modal-title-cmp">Break Down Date</Label>
                        <Input type="date" onChange={(e) => this.breakDownDate(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                    </Col>
                    <Col sm="6" lg="3">
                        <Label className="modal-title-cmp">Break Down Time</Label>
                        <Input type="time" onChange={(e) => this.breakDownTime(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>   
                        </Col>
                    </Row>
                    <Row className="m-t1">
                        <Col sm="6" lg="3">
                            <Label className="modal-title-cmp">Material</Label>
                            <Input type="text"onChange={(e) => this.material(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                        </Col>
                        <Col sm="6" lg="3">
                            <Label className="modal-title-cmp">Material Description</Label>
                            <Input type="text" onChange={(e) => this.materialDescription(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>   
                        </Col>
                        <Col sm="6" lg="3">
                            <Label className="modal-title-cmp">Author No.</Label>
                            <Input type="text" onChange={(e) => this.author(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>
                        </Col>
                        <Col sm="6" lg="3">
                            <Label className="modal-title-cmp">Name</Label>
                            <Input type="text" onChange={(e) => this.name(`${e.target.value}`)}className="modal-input-cmp p-l10"></Input>   
                        </Col>
                    </Row>
                    <Row className="m-t1">
                        <Col sm="12">
                          <FormGroup>
                            <Label htmlFor="warranty-type" className="modal-title-cmp">Problem Descripton</Label>
                            <Input type="textarea" onChange={(e) => this.description(`${e.target.value}`)} className="modal-input-cmp"></Input>
                          </FormGroup>
                        </Col>
                    </Row>
                    <Row className="m-t3 m-b2">
                        <Col sm="6">
                            <Button type="button"  color="danger" className="p-lr3" >DELETE</Button>
                        </Col>
                        <Col sm="3" >
                            <Button onClick={this.toggle} type="button" outline  color="danger" className="p-lr3 cmp-floatRight" >CANCEL</Button>
                        </Col>
                        <Col sm="3">
                            <Button type="button" onClick={this.createServices.bind(this)} color="success" className="p-lr3 cmp-floatRight" >CREATE</Button>
                        </Col>
                    </Row>
                  </CardBody>
                </Card>
            </ModalBody>
        </Modal>
        {/* Modal for Create service ends here */}
         {/*Modal for viewing a service*/}
         <Modal isOpen={this.state.modal1} toggle={this.toggle1} className={'modal-xl ' + this.props.className}>
            <ModalBody>
                {serviceForModal.map(service=>
                <Card>
                    <CardBody>
                        <h4 className="m-b2">ID-{service.id}, {service.service}</h4>
                        <Row>
                            <Col lg="3">
                                <Label className="modal-title-cmp">Service Type</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.service}</Label></Card>
                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Status</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.status}</Label></Card>
                            </Col>
                            <Col lg="6">
                                <Label  className="modal-title-cmp">Percentage Completed</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.percentage}%</Label></Card>
                            </Col>
                        </Row>
                        <Row>
                            <Col lg="3">
                            <FormGroup>
                                <Label className="modal-title-cmp">Estimated Date</Label>
                                    <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.EndDate}</Label></Card>
                            </FormGroup>
                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Reference Date</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.StartDate}</Label></Card>
                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Last Update Date</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.lastUpdated}</Label></Card>
                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Updated By</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.updatedBy}</Label></Card>
                            </Col>
                            </Row>
                            <Row>
                            <Col lg="3">
                                <FormGroup>
                                    <Label  className="modal-title-cmp">Break Down Date</Label>
                                    <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.breakDownDate}</Label></Card>
                                </FormGroup>
                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Break Down Time</Label>
                                <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.breakDownTime} hrs</Label></Card>
                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Total Amount</Label>
                                <InputGroup>
                                    <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{service.totalAmount}</Label></Card>
                                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                                </InputGroup>

                            </Col>
                            <Col lg="3">
                                <Label  className="modal-title-cmp">Total Material</Label>
                                <InputGroup>
                                    <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{service.totalMaterial}</Label></Card>
                                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                                </InputGroup>
                            </Col>
                            </Row>
                            <Row>
                                <Col lg="3">
                                <FormGroup>
                                    <Label  className="modal-title-cmp">Total Labour Value</Label>
                                    <InputGroup>
                                        <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{service.totalLabour}</Label></Card>
                                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                                    </InputGroup>
                                </FormGroup>
                                </Col>
                                <Col lg="3">
                                    <Label  className="modal-title-cmp">Total External Service</Label>
                                    <InputGroup>
                                        <InputGroupAddon addonType="prepend">$</InputGroupAddon>
                                        <Card className="modal-input-cmp p-l10 m-0 p-t5px width13"><Label className="fs-1">{service.totalExternal}</Label></Card>
                                        {/* <InputGroupAddon addonType="append">.00</InputGroupAddon> */}
                                    </InputGroup>
                                </Col>
                                <Col lg="3">
                                    <Label  className="modal-title-cmp">Material</Label>
                                    <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.material}</Label></Card>
                                </Col>
                                <Col lg="3">
                                    <Label  className="modal-title-cmp">Material Description</Label>
                                    <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.materialDescription}</Label></Card>
                                </Col>
                                </Row>
                                <Row>
                                    <Col lg="12">
                                        <FormGroup>
                                            <Label  className="modal-title-cmp">Problem description</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="fs-1 p-t5px">{service.description}</Label></Card>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="m-t3 m-b2">
                                    <Col lg="7" md="4">
                                        <Button  color="danger" className="p-lr2">DELETE</Button>
                                    </Col>
                                    <Col lg="3" md="4">
                                        <Button onClick={this.toggle1} type="button" outline color="danger" className="p-lr2 cmp-floatRight" >CANCEL</Button>
                                    </Col>
                                    <Col lg="2" md="4">
                                        <Button  color="success" className="p-lr2 cmp-floatRight">REGISTER</Button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                        )}
                    </ModalBody>
                </Modal>
                {/*Modal for viewing a service ends here*/}

            {/* Charts and Tiles*/}
        <div className="col-lg-12 col-md-12 col-sm-12 b-col displayFlex border m-b2"> 
            
            <div className="col-lg-6 col-md-5 col-sm-5 m-b1 p-t3">
                <Doughnut data={doughnut} />
            </div>
            <div className="col-lg-4 col-md-4 col-sm-4  displayFlex">
                <div className="col-lg-10 col-md-9 col-sm-12 p-t2 m-l2 p-t3">
                    <div className="col-lg-12 col-md-12 col-sm-12 tile-service cmp-iconCol-warning">
                        <p className="font txt-cmp-white pt2">PENDING SERVICES</p>
                            <div className="displayFlex">
                                <p className="p-t5px"><GiGears className="iconVal-service cmp-iconCol-warning" size="36"/> </p>
                                <p className="font-num-service txt-cmp-white center">05</p>                                  
                            </div>
                    </div> 
                    <div className="col-lg-12 col-md-12 col-sm-12 tile-service bg-cmp-success">
                        <p className="font txt-cmp-white">TOTAL SERVICE COST</p>
                        <div className="displayFlex">
                        {/* <p className="p-t5px"><FaDollarSign className="iconVal-service cmp-iconCol-success" size="36"/> </p> */}
                            <p className="font-num-service center txt-cmp-white p-l1">$1320</p>
                        </div>
                    </div>                
                </div>
                <div className="col-lg-2 col-md-2 col-sm-2  p-t10px">
                    <Input type="select" name="filter" id="graphFilter" className="cmp-service-filter bg-cmp-primary txt-cmp-white cmp-width10" >
                      <option value="0">Last 3 Months</option>
                      <option value="1">Last Week</option>
                      <option value="2">Last 15 Days</option>
                      <option value="3">Last 30 Days</option>
                    </Input>
                </div>
            </div>
        </div>   


            <Card>
                  <CardHeader>
                         <FormGroup>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="p-t10px">PENDING SERVICES</h5>
                                    </Col>
                                    <Col>
                                        <Button type="button" color="info" outline className="cmp-floatRight" onClick={this.handlePageChange}>All Services</Button>
                                    </Col> 
                                </InputGroup>
                            </div>
                            </FormGroup>
                  </CardHeader>
                  <CardBody>
                        
                  <Table responsive striped size="lg" >
                    <thead>
                        <tr>
                            <th>SERVICE</th>
                            <th className="center">STATUS</th>
                            <th className="center p-r4">DATE</th>
                            <th>ACTION</th>
                            <th>  </th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.serviceData.map(service=>
                        <tr>
                            {service.percentage < 100 ?<td>
                                <div>
                                    <p className="title-cmp padding0 margin0">{service.service}, <Label className="title-cmp margin0 cmp-checkColor">{service.vin}</Label> </p>
                                </div>
                              
                              <p className="description-cmp cmp-mw-18">{service.description}</p>
                            </td>: null}

                            {service.percentage<100 ?                      
                            <td>
                            <Row >
                                <Col className="displayFlex title-cmp" sm="3">{service.percentage}%</Col>
                                <Col sm="9" className="">
                                <p className="cmp-border0 cmp-floatRight">
                                    {service.StartDate == Moment().format("MMM DD, YYYY") ? <Label className="txt-cmp-info cmp-smallFont-Bold">New</Label>  : null}
                                    {service.EndDate < Moment().format("MMM DD, YYYY") && (service.percentage < 25) ? <Label className="txt-cmp-danger cmp-smallFont-Bold">Over Due</Label>  : null}
                                    {(service.percentage >= 25) && (service.percentage < 60) ? <Label className="txt-cmp-warning cmp-smallFont-Bold" >Delay</Label> : null}
                                    {(service.percentage >= 60) && (service.percentage <= 99) ? <Label className="txt-cmp-info cmp-smallFont-Bold">On Track</Label> : null}
                                    {service.percentage == 100 ?<Label className="txt-cmp-success cmp-smallFont-Bold">Completed</Label> : null}                      
                                </p></Col>
                            </Row>             
                            <Row>

                                {service.percentage < 25 ? <Col><Progress value={service.percentage} color="danger" className="mb-3" className="progress-cmp" /></Col> : null}
                                {(service.percentage >= 25) && (service.percentage < 60) ? <Col><Progress value={service.percentage} color="warning" className="mb-3" className="progress-cmp" /></Col> : null}
                                {(service.percentage >= 60) && (service.percentage < 100) ? <Col><Progress value={service.percentage} color="info" className="mb-3" className="progress-cmp" /></Col> : null}
                                {service.percentage > 99 ? <Col><Progress value={service.percentage} color="success" className="mb-3" className="progress-cmp" /></Col> : null}

                            </Row>
                            </td>: null}
                            {service.percentage<100 ?<td>
                                <Row>
                                <Col>
                                    <p className="cmp-smallFont m-0">Created on: {service.StartDate}</p> 
                                    <p className="cmp-smallFont-Bold">Estimated on: {service.EndDate}</p></Col>                    
                                </Row>
                            </td>: null}
                                {service.percentage<100 ?<td>
                                    <p className=" m-0">{service.serviceDetail}</p>
                                    <p className="text-muted small m-0">Last Updated: {service.lastUpdated}</p>
                                </td>: null}
                                {service.percentage<100 ?<td><Button type="button" size="sm" color="info" onClick={this.toggle1.bind(this, service.id)}>View</Button></td>: null}
                        </tr> 
                        )}
                       
                    </tbody>
                    
                  </Table>
                  </CardBody>
                  </Card>
      </div>
    );
  }
}

export default Services;
