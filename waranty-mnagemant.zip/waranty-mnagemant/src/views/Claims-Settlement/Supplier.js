import React, { Component } from 'react';
import { Col, Row, Button,InputGroupAddon, Table, CardHeader, FormGroup, Input, Label, Modal, ModalBody, CardBody, InputGroup, Card } from 'reactstrap';
import '../../StyleSheet/Default.css';

var data= require('../Claims-Settlement/Customer.json')
class Customer extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            modal:false,
            modal1:false,
            customerData:data,
            product:"",
            Supplier:"",
            claimNo:"",
            itemNo:"",
            purchaseOrderNo:"",
            billingDate:"",
            quantity:"",
            netValue:"",
            claimValue:""
         }
        this.toggle= this.toggle.bind(this);
    }
    toggle() {
        this.setState({
            modal: !this.state.modal,
        });
    }
    toggle1(Id) {
        this.setState({
            modal1: !this.state.modal1,
            customerId: Id
        });
    }
    product(value){
        this.setState({
            product:value,
        })
    } 
    supplier(value){
        this.setState({
            supplier:value,
        })
    }
    claimNo(value){
        this.setState({
            claimNo:value,
        })
    }
    itemNo(value){
        this.setState({
            itemNo:value,
        })
    }
    purchaseOrderNo(value){
        this.setState({
            purchaseOrderNo:value,
        })
    }
    billingDate(value){
        this.setState({
            billingDate:value,
        })
    }
    quantity(value){
        this.setState({
            quantity:value,
        })
    }
    netValue(value){
        this.setState({
            netValue:value,
        })
    }
    claimValue(value){
        this.setState({
            claimValue:value,
        })
    }
    createCustomer(){
        if(this.state.product!=="" && this.state.supplier!=="")
        {
            var requestBody={
                "product":this.state.product,
                "supplier":this.state.supplier,
                "claimNo":this.state.claimNo,
                "itemNo":this.state.itemNo,
                "purchaseOrderNo":this.state.purchaseOrderNo,
                "billingDate":this.state.billingDate,
                "quantity":this.state.quantity,
                "netValue":this.state.netValue,
                "claimValue":this.state.claimValue,
                "debitMemoNo":"2100454",
                "description":"To be Replaced",
                "serviceRenderedDate":"Aug 26, 2019",
                "pricingDate":"April 10, 2019"

            }
            this.state.customerData.unshift(requestBody);
        }
        else{
            alert("Fill the Mandatory Value");
        }
        this.setState({
            modal: false,
          });
      
    }
    render() { 
        var customerForModal = [];
        if (this.state.customerId) {
            this.state.customerData.map(customer => {
                if (customer.purchaseOrderNo === this.state.customerId) {
                    customerForModal.push(customer);
                }
            })
        }
        return ( 
            <div className="animated fadeIn p-lr1">
                {/* Modal for creating a Debit memo*/}
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        <Card className="p-lr6">
                            <CardBody>
                                <h4 className="m-b2">CREATE DEBIT MEMO</h4>
                                <Row className="m-t1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Product</Label>
                                        <Input type="text" onChange={(e) => this.product(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Supplier</Label>
                                        <Input type="text" onChange={(e) => this.supplier(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Claim No.</Label>
                                        <Input type="text" onChange={(e) => this.claimNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Item No.</Label>
                                        <Input type="text" onChange={(e) => this.itemNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Purchase Order No.</Label>
                                        <Input type="text" onChange={(e) => this.purchaseOrderNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Billing Date</Label>
                                        <Input type="text" onChange={(e) => this.billingDate(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Quantity</Label>
                                        <Input type="text" onChange={(e) => this.quantity(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Net Value</Label>
                                        <Input type="text" onChange={(e) => this.netValue(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Claim Value</Label>
                                        <Input type="text" onChange={(e) => this.claimValue(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                
                                <Row className="modal-title-cmp mt-3">
                                    <Col sm="6">
                                        <Button onClick={this.toggle} type="button" outline color="danger" className="p-lr3" >CANCEL</Button>
                                    </Col>
                                    <Col sm="6">
                                        <Button type="button" color="success" onClick={this.createCustomer.bind(this)} className="p-lr3 cmp-floatRight" >CREATE</Button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </ModalBody>
                </Modal>

                {/* Modal for viewing the Debit Memo list */}
                <Modal isOpen={this.state.modal1} toggle={this.toggle1.bind(this)} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                       {customerForModal.map(customer =>
                            <Card>
                                <CardBody>
                                    <Row ><h3 className="m-l2">ID-{customer.debitMemoNo}, {customer.supplier}</h3></Row>
                                    <Row className="m-t2">
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Product</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16"> {customer.product}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Supplier</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16"> {customer.supplier}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Net Value</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">${customer.netValue} </Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Claim No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.claimNo}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Claim Value</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">${customer.claimValue} </Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Purchase Order No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.purchaseOrderNo}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Item No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.itemNo}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Quantity</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.quantity}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Description</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.description}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Billing Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.billingDate}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Service Rendered Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.serviceRenderedDate}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Pricing Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{customer.pricingDate}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row className="m-t3 m-b2">
                                        <Col sm="12">
                                            <Button onClick={this.toggle1.bind(this)} type="button" outline color="danger" className="p-lr3 cmp-floatRight" >CLOSE</Button>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        )}
                    </ModalBody>
                </Modal>


                <Row className="display-block cmp-floatRight m-b-5px">
                    <div >
                        <Button onClick={this.toggle} type="button" color="primary" className="">CREATE DEBIT MEMO REQUEST</Button>
                    </div>
                </Row>
                <Row className="display-block">
                <Card className="col-12 p-0">
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">DEBIT MEMO LIST</h5>
                                    </Col> 
                                    <Col>
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="cmp-searchBar-width" placeholder="Search Debit memo No...." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>

                                <Table responsive striped size="lg" >
                                    <thead>
                                        <tr>
                                            <th>DEBIT MEMO NO.</th>
                                            <th className="center">PURCHASE ORDER NO.</th>
                                            <th>SUPPLIER</th>
                                            <th>PRODUCT</th>
                                            <th className="center">QUANTITY</th>
                                            <th className="center">PRICE</th>
                                            <th className="center">CLAIM VALUE</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.state.customerData.map(customer =>
                                            <tr>
                                                <td>{customer.debitMemoNo}</td>
                                                <td className="center">{customer.purchaseOrderNo}</td>
                                                <td>{customer.supplier}</td>
                                                <td>{customer.product}</td>
                                                <td className="center">{customer.quantity}</td>
                                                <td className="center">${customer.netValue} </td>
                                                <td className="center"> ${customer.claimValue}</td>
                                                <td><Button onClick={this.toggle1.bind(this, customer.purchaseOrderNo)} className="btn-info btn-sm ">View</Button></td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>
                            </CardBody>
                         </Card>
                </Row>
            </div>
        
         );

    }
}
 
export default Customer;