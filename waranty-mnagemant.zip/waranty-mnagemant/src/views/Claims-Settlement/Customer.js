import React, { Component } from 'react';
import { Col, Row,InputGroupAddon, Button, Table, CardHeader, FormGroup, Input, Label, Modal, ModalBody, CardBody, InputGroup, Card } from 'reactstrap';
import '../../StyleSheet/Default.css';

var data= require('../Claims-Settlement/Supplier.json')
class Supplier extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            modal:false,
            modal1:false,
            supplierData:data,
            product:"",
            customer:"",
            claimNo:"",
            itemNo:"",
            purchaseOrderNo:"",
            billingDate:"",
            quantity:"",
            netValue:"",
            claimValue:""
         }
        this.toggle= this.toggle.bind(this);
    }
    toggle() {
        this.setState({
            modal: !this.state.modal,
        });
    }
    toggle1(Id) {
        this.setState({
            modal1: !this.state.modal1,
            supplierId: Id
        });
    }
    product(value){
        this.setState({
            product:value,
        })
    } 
    customer(value){
        this.setState({
            customer:value,
        })
    }
    claimNo(value){
        this.setState({
            claimNo:value,
        })
    }
    itemNo(value){
        this.setState({
            itemNo:value,
        })
    }
    purchaseOrderNo(value){
        this.setState({
            purchaseOrderNo:value,
        })
    }
    billingDate(value){
        this.setState({
            billingDate:value,
        })
    }
    quantity(value){
        this.setState({
            quantity:value,
        })
    }
    netValue(value){
        this.setState({
            netValue:value,
        })
    }
    claimValue(value){
        this.setState({
            claimValue:value,
        })
    }
    createSupplier(){
        if(this.state.product!=="" && this.state.customer!=="")
        {
            var requestBody={
                "product":this.state.product,
                "customer":this.state.customer,
                "claimNo":this.state.claimNo,
                "itemNo":this.state.itemNo,
                "purchaseOrderNo":this.state.purchaseOrderNo,
                "billingDate":this.state.billingDate,
                "quantity":this.state.quantity,
                "netValue":this.state.netValue,
                "claimValue":this.state.claimValue,
                "creditMemoNo":"2100454",
                "description":"To be Replaced",
                "serviceRenderedDate":"Aug 26, 2019",
                "pricingDate":"April 10, 2019"

            }
            this.state.supplierData.unshift(requestBody);
        }
        else{
            alert("Fill the Mandatory Value");
        }
        this.setState({
            modal: false,
          });
      
    }
    render() { 
        var supplierForModal = [];
        if (this.state.supplierId) {
            this.state.supplierData.map(supplier => {
                if (supplier.purchaseOrderNo === this.state.supplierId) {
                    supplierForModal.push(supplier);
                }
            })
        }
        return ( 
            <div className="animated fadeIn p-lr1">
                {/* Modal for creating a Debit memo*/}
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        <Card className="p-lr6">
                            <CardBody>
                                <h4 className="m-b2">CREATE DEBIT MEMO</h4>
                                <Row className="m-t1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Product</Label>
                                        <Input type="text" onChange={(e) => this.product(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Customer</Label>
                                        <Input type="text" onChange={(e) => this.customer(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Claim No.</Label>
                                        <Input type="text" onChange={(e) => this.claimNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Item No.</Label>
                                        <Input type="text" onChange={(e) => this.itemNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Sales Order No.</Label>
                                        <Input type="text" onChange={(e) => this.purchaseOrderNo(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Billing Date</Label>
                                        <Input type="date" onChange={(e) => this.billingDate(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Quantity</Label>
                                        <Input type="text" onChange={(e) => this.quantity(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Net Value</Label>
                                        <Input type="text" onChange={(e) => this.netValue(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Claim Value</Label>
                                        <Input type="text" onChange={(e) => this.claimValue(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                
                                <Row className="modal-title-cmp mt-3">
                                    <Col sm="6">
                                        <Button onClick={this.toggle} type="button" outline color="danger" className="p-lr3" >CANCEL</Button>
                                    </Col>
                                    <Col sm="6">
                                        <Button type="button" color="success" onClick={this.createSupplier.bind(this)} className="p-lr3 cmp-floatRight" >CREATE</Button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </ModalBody>
                </Modal>

                {/* Modal for viewing the Debit Memo list */}
                <Modal isOpen={this.state.modal1} toggle={this.toggle1.bind(this)} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                       {supplierForModal.map(supplier =>
                            <Card>
                                <CardBody>
                                    <Row ><h3 className="m-l2">ID-{supplier.creditMemoNo}, {supplier.customer}</h3></Row>
                                    <Row className="m-t2">
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Product</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16"> {supplier.product}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Customer</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16"> {supplier.customer}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Net Value</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">${supplier.netValue} </Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Claim No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.claimNo}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Claim Value</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">${supplier.claimValue} </Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Sales Order No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.purchaseOrderNo}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Item No.</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.itemNo}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Quantity</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.quantity}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Description</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.description}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Billing Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.billingDate}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Service Rendered Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.serviceRenderedDate}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Pricing Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16">{supplier.pricingDate}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row className="m-t3 m-b2">
                                        <Col sm="12">
                                            <Button onClick={this.toggle1.bind(this)} type="button" outline color="danger" className="p-lr3 cmp-floatRight" >CLOSE</Button>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        )}
                    </ModalBody>
                </Modal>


                <Row className="display-block cmp-floatRight m-b-5px">
                    <div >
                        <Button onClick={this.toggle} type="button" color="primary"  className=" ">CREATE CREDIT MEMO REQUEST</Button>
                    </div>
                </Row>
                <Row className="display-block">
                <Card className="col-12 p-0">
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">CREDIT MEMO LIST</h5>
                                    </Col> 
                                    <Col>
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="cmp-searchBar-width" placeholder="Search for Credit memo No...." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>

                                <Table responsive striped size="lg" >
                                    <thead>
                                        <tr>
                                            <th>CREDIT MEMO NO.</th>
                                            <th className="center">SALES ORDER NO.</th>
                                            <th>CUSTOMER</th>
                                            <th>PRODUCT</th>
                                            <th className="center">QUANTITY</th>
                                            <th className="center">PRICE</th>
                                            <th className="center">CLAIM VALUE</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.state.supplierData.map(supplier =>
                                            <tr>
                                                <td>{supplier.creditMemoNo}</td>
                                                <td className="center">{supplier.purchaseOrderNo}</td>
                                                <td>{supplier.customer}</td>
                                                <td>{supplier.product}</td>
                                                <td className="center">{supplier.quantity}</td>
                                                <td className="center">${supplier.netValue} </td>
                                                <td className="center">${supplier.claimValue} </td>
                                                <td><Button onClick={this.toggle1.bind(this, supplier.purchaseOrderNo)} className="btn-info btn-sm ">View</Button></td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>
                            </CardBody>
                         </Card>
                </Row>
            </div>
        
         );

    }
}
 
export default Supplier;

