import React, { Component } from 'react';
import { Col, Row, Button, Table, InputGroupAddon, CardHeader, FormGroup, Input, Label, Modal, ModalBody, CardBody, InputGroup, Card } from 'reactstrap';
// import '../Supplier-Recovery/Supplier-Recovery.css'
import '../../StyleSheet/Default.css';

var data = require('../Supplier-Recovery/Supplier-Recovery.json')
class SupplierRecovery extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modal: false,
            modal1: false,
            recoveryData: data,
            supplierId:"",
            claimno:"",
            suppliername:"",
            servicetype:"",
            casualpart:" ",
            status:" ",
            lastupdated:" ",
            recoverymanager:"",
            failuredate:"",
            repairdate:"",
            failuredescription:" ",
            equipmentno:"",
            inventoryitemno:"",
            defectcode:""
        }
        this.toggle = this.toggle.bind(this);
    }
    toggle() {
        this.setState({
            modal: !this.state.modal,
        });
    }
    toggle1(Id) {
        this.setState({
            modal1: !this.state.modal1,
            recoveryId: Id
        });
    }
    supplierid(value){
        this.setState({
            supplierid:value,
        })
    }
    claimno(value){
        this.setState({
            claimno:value,
        })
    }
    suppliername(value){
        this.setState({
            suppliername:value,
        })
    }
    servicetype(value){
        this.setState({
            servicetype:value,
        })
    }
    casualpart(value){
        this.setState({
            casualpart:value,
        })
    }
    lastupdated(value){
        this.setState({
            lastupdated:value,
        })
    }
    recoverymanager(value){
        this.setState({
            recoverymanager:value,
        })
    }
    failuredate(value){
        this.setState({
            failuredate:value,
        })
    }
    repairdate(value){
        this.setState({
            repairdate:value,
        })
    }
    failuredescription(value){
        this.setState({
            failuredescription:value,
        })
    }
    equipmentno(value){
        this.setState({
            equipmentno:value,
        })
    }
    inventoryitemno(value){
        this.setState({
            inventoryitemno:value,
        })
    }
    defectcode(value){
        this.setState({
            defectcode:value,
        })
    }
    
    createRecovery(){
        if(this.state.supplierid!=="" && this.state.suppliername!== ""){
            var requestBody ={
                "id":this.state.supplierid,
                "claimNo":Math.floor(Math.random()*100000),
                "supplierName":this.state.suppliername,
                "serviceType":"A/C",
                "casualPart":this.state.casualpart,
                "status":"Approved",
                "lastUpdated":"19 Aug, 2019",
                "recoveryManager":this.state.recoverymanager,
                "failuredate":this.state.failuredate,
                "repairDate":this.state.repairdate,
                "failureDescription":this.state.failuredescription
                               
            }
        this.state.recoveryData.unshift(requestBody);
    }
        else{
            alert("Fill the Mandatory value");
        }
    this.setState({
            modal: false,
          });
      
    }

    render() {
        var recoveryForModal = [];
        if (this.state.recoveryId) {
            this.state.recoveryData.map(recovery => {
                if (recovery.id === this.state.recoveryId) {
                    recoveryForModal.push(recovery);
                }
            })
        }
        return (
            <div className="animated fadeIn p-lr1">
                {/* Modal for creating a Supplier- Recovery*/}
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        <Card className="p-lr6">
                            <CardBody>
                                <h4 className="m-b2">CREATE SUPPLIER RECOVERY</h4>
                                <Row className="m-t1">
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Supplier ID</Label>
                                        <Input type="text" onChange={(e) => this.supplierid(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Supplier Name</Label>
                                        <Input type="text" onChange={(e) => this.suppliername(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col md="4">
                                        <Label className="modal-title-cmp">Recovery Manager</Label>
                                        <Input type="text" onChange={(e) => this.recoverymanager(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Equipment No.</Label>
                                        <Input type="text" onChange={(e) => this.equipmentno(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Inventory Item No.</Label>
                                        <Input type="text" onChange={(e) => this.inventoryitemno(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Casual Part</Label>
                                        <Input type="text" onChange={(e) => this.casualpart(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Defect Code</Label>
                                        <Input type="text" onChange={(e) => this.defectcode(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Failure Date</Label>
                                        <Input type="text" onChange={(e) => this.failuredate(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                    <Col sm="4">
                                        <Label className="modal-title-cmp">Repair Date</Label>
                                        <Input type="text" onChange={(e) => this.repairdate(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                    </Col>
                                </Row>
                                <Row className="m-t1">
                                    <Col sm="12">
                                        <FormGroup>
                                            <Label className="modal-title-cmp">Failure Descripton</Label>
                                            <Input type="textarea" onChange={(e) => this.failuredescription(`${e.target.value}`)} className="modal-input-cmp p-l10"></Input>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row className="modal-title-cmp">
                                    <Col sm="6">
                                        <Button onClick={this.toggle} type="button" outline color="danger" className="p-lr3" >CANCEL</Button>
                                    </Col>
                                    <Col sm="6">
                                        <Button type="button" color="success" onClick={this.createRecovery.bind(this)} className="p-lr3 cmp-floatRight" >CREATE</Button>
                                    </Col>
                                </Row>
                            </CardBody>
                        </Card>
                    </ModalBody>
                </Modal>

                {/* Modal for viewing the supplier Recovery list */}
                <Modal isOpen={this.state.modal1} toggle={this.toggle1.bind(this)} className={'modal-xl ' + this.props.className}>
                    <ModalBody>
                        {recoveryForModal.map(recovery =>
                            <Card>
                                <CardBody>
                                    <Row ><h3 className="m-l2">ID-{recovery.claimNo}, {recovery.supplierName}</h3></Row>
                                    <Row className="m-t2">
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Supplier ID</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px"> {recovery.claimNo}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Supplier Name</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px"> {recovery.supplierName}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Recovery Manager</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.recoveryManager}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Status</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.status}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Service Type</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.serviceType}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Casual Part</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.casualPart}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Failure Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.failuredate}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Repair Date</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.repairDate}</Label></Card>
                                        </Col>
                                        <Col sm="4">
                                            <Label className="modal-title-cmp">Failure Description</Label>
                                            <Card className="modal-input-cmp p-l10"><Label className="font-size16 p-t5px">{recovery.failureDescription}</Label></Card>
                                        </Col>
                                    </Row>
                                    <Row className="m-t3 m-b2">
                                        <Col sm="12">
                                            <Button onClick={this.toggle1.bind(this)} type="button" outline color="danger" className="p-lr3 cmp-floatRight" >CLOSE</Button>
                                        </Col>
                                    </Row>
                                </CardBody>
                            </Card>
                        )}
                    </ModalBody>
                </Modal>


                <Row className="display-block cmp-floatRight m-b-5px">
                    <div >
                        <Button onClick={this.toggle} type="button" color="primary"  className="">CREATE SUPPLIER RECOVERY</Button>
                    </div>
                </Row>
                <Row className="display-block">
                <Card className="col-12 p-0">
                  <CardHeader>
                            <div >
                                <InputGroup>
                                    <Col>
                                        <h5 className="pt-10">SUPPLIER RECOVERY LIST</h5>
                                    </Col> 
                                    <Col>
                                    <div className="cmp-floatRight">
                                    <InputGroup>
                                        <Col xs="9">
                                        <Input id="appendedInputButton" className="width15"  placeholder="Search for Supplier Recovery ID...." type="text" />
                                        </Col> 
                                        <InputGroupAddon addonType="append">
                                        <Button color="info">Go!</Button>
                                        </InputGroupAddon>
                                    </InputGroup>
                                    </div>
                                    </Col>
                                </InputGroup>
                            </div>
                  </CardHeader>
                  <CardBody>

                                <Table responsive striped size="lg" >
                                    <thead>
                                        <tr>
                                            <th>CLAIM NO.</th>
                                            <th>SUPPLIER NAME</th>
                                            <th>SERVICE TYPE</th>
                                            <th>CASUAL PART</th>
                                            <th>STATUS</th>
                                            <th>LAST UPDATED</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {this.state.recoveryData.map(recovery =>
                                            <tr>
                                                <td>{recovery.claimNo}</td>
                                                <td>{recovery.supplierName}</td>
                                                <td>{recovery.serviceType}</td>
                                                <td>{recovery.casualPart}</td>
                                                <td>{recovery.status}</td>
                                                <td>{recovery.lastUpdated}</td>
                                                <td><Button onClick={this.toggle1.bind(this, recovery.id)} className="btn-info btn-sm ">View</Button></td>
                                            </tr>
                                        )}
                                    </tbody>
                                </Table>
                            </CardBody>
                         </Card>
                </Row>
            </div>
        );
    }
}

export default SupplierRecovery;