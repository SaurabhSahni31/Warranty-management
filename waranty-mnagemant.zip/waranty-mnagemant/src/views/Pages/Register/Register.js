import React, { Component } from 'react';
import { Card, CardImg, Label, Container, CardGroup, FormGroup, Input, Button, CardBody, Col, Form, Row } from 'reactstrap';
import '../../../StyleSheet/Default.css';
import image from '../../../assets/img/1.png';
class Signup extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    } 

    submitForm(e) {
        e.preventDefault()
        this.props.history.push('../Login/Login');
    }
    routeChange(e){
        e.preventDefault()
        this.props.history.push('../Login/Login')
    }
    render() {
        return (
            <div className="app flex-row align-items-center cmp-bgc">
                <Container   className="cmp-signin-container">
                    <Row className="justify-content-center">
                        <Col xs="12" sm="12" md="12" lg="6">
                            <CardGroup>
                                <Card className="p-4">
                                    <CardBody>
                                        <Form onSubmit={this.submitForm.bind(this)}>
                                            <Col>
                                                <CardImg className="imgsize" alt='icon' src={image} size='100px'/>
                                            </Col>
                                            <p className="text-center signin">Sign Up</p>
                                            <Row>
                                                <Col xs="12">
                                                    <FormGroup>
                                                        <Label className="cmp-login-title">First Name</Label>
                                                        <Input type="text" id="fname" className="validate " required />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs="12">
                                                    <FormGroup>
                                                        <Label className="cmp-login-title">Last Name</Label>
                                                        <Input type="text" id="lname" className="validate " required />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs="12">
                                                    <FormGroup>
                                                        <Label className="cmp-login-title">Email Address</Label>
                                                        <Input type="email" id="email" className="validate " required />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs="12">
                                                    <FormGroup>
                                                        <Label className="cmp-login-title">Password</Label>
                                                        <Input type="password" id="password" required />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs="12">
                                                    <FormGroup className="p-l1 cmp-checkColor">
                                                        <p><Input type="checkbox" required ></Input>I Accept to the<Button color="link" className="px-0" >Terms and Conditions</Button></p>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Col xs="12" className="text-right">
                                                <Button type="submit" color="info" className="px-4">SignUp</Button>
                                            </Col>
                                        </Form>
                                    </CardBody>
                                </Card>
                            </CardGroup>
                            <p class="text-center signup">Current Subscribers ?&nbsp;&nbsp;
                                <Button href="/login#/login" color="link" className="px-0" >Sign In</Button>
                            </p>
                        </Col>
                    </Row>
                </Container>
            </div>
        )
    }
}
export default Signup
