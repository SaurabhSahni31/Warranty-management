import React, { Component } from 'react';
import { Label, FormGroup, Input, Button, CardBody, Col, Form } from 'reactstrap';
import ImageUpLoad from "./ImageUpload";
import Select from 'react-select';
import "./MyAccount.css"


const Page = [
    { label: "South", value: 1 },
    { label: "Midwest", value: 2 },
  ];
  const Records = [
      { label: "20", value: 1 },
      { label: "40", value: 2 },
      { label: "60", value: 3 },
  ];

class MyAccount extends Component {
    render() {
      return (
        <div className="col-lg-12 col-md-12 col-sm-12 border p-t1 frame-bg m-b">
        <h2>Basic Profile</h2>
        <div className="col-lg-12 col-md-12 col-sm-12 displayFlex padding0 m-b">  
            <div className="col-lg-4 col-md-4 col-sm-4 ">
                <div className="col-lg-12 col-md-12 col-sm-12"> 
                    <CardBody>
                    <Form>
                    <FormGroup>
                        <Label  className="formValue">Name </Label>
                        <Input type="text" id="name" placeholder="John Doe" className="modal-input-cmp" required />
                    </FormGroup>
                    <FormGroup>
                        <Label  className="formValue" htmlFor="email">Email Address</Label>
                        <Input type="email" id="email" className="validate modal-input-cmp" placeholder="johndoe@example.com" required />
                    </FormGroup>
                    <FormGroup>
                        <Label  className="formValue"> Address</Label>
                        <Input type="text" id="address" className="modal-input-cmp" required />
                    </FormGroup>
                    <Col xs="12" className="text-right">
                        <Button type="submit" color="danger" className="cancel">Cancel</Button>
                        <Button type="submit" color="success" className="edit">Edit</Button>
                    </Col>
                    </Form>  
                    </CardBody>   
                </div>
            </div>

            <div className="col-lg-4 col-md-4 col-sm-4 ">
                <div className="col-lg-12 col-md-12 col-sm-12 ">
                <div className="">
                <CardBody>
                    <Form>
                    <FormGroup>
                        <Label  className="formValue">Last Name </Label>
                        <Input type="text" id="lastname" placeholder="Doe" className="modal-input-cmp" required />
                    </FormGroup>
                    <FormGroup>
                        <Label  className="formValue">Mobile Number </Label>
                        <Input type="number" id="mobile" className="modal-input-cmp"required />
                    </FormGroup>
                    </Form>  
                    </CardBody>   
                    </div>
                </div>
            </div>

            <div className="col-lg-4 col-md-4 col-sm-4 ">
                <ImageUpLoad />
            </div>
        </div>

        <div className="col-lg-12 col-md-12 col-sm-12 divide p-t1 m-b">  
        <h3>Edit Password</h3>
        <div className="col-lg-12 col-md-12 col-sm-12 displayFlex  m-b">  
            <div className="col-lg-4 col-md-4 col-sm-4 ">
            
                <div className="col-lg-12 col-md-12 col-sm-12  ">  
                
                    <CardBody>
                    <Form>
                    <FormGroup>
                        <Label  className="formValue">Current Password </Label>
                        <Input type="password" id="curentpass" className="modal-input-cmp"required />
                    </FormGroup>
                    <Col xs="12" className="text-right">
                        <Button type="submit" color="danger" className="cancel">Cancel</Button>
                        <Button type="submit" color="success" className="edit">Edit</Button>
                    </Col>
                    </Form>  
                    </CardBody>   
                </div>
            </div>

            <div className="col-lg-4 col-md-4 col-sm-4 ">
                <div className="col-lg-12 col-md-12 col-sm-12 ">
                <div className="">
                <CardBody>
                    <Form>
                    <FormGroup>
                        <Label  className="formValue">New Password </Label>
                        <Input type="password" id="newpass"className="modal-input-cmp" required />
                    </FormGroup>
                    </Form>  
                    </CardBody>   
                    </div>
                </div>
            </div>
            <div className="col-lg-4 col-md-4 col-sm-4 ">
            <CardBody>
                    <Form>
                    <FormGroup>
                        <Label  className="formValue">Conform Password </Label>
                        <Input type="password" id="conpass"className="modal-input-cmp" required />
                    </FormGroup>
                    <Col xs="12" className="text-right">
                        <Button type="save" color="info" className="save">Save</Button>
                    </Col>
                    </Form>  
                    </CardBody> 
            </div>
        </div>
        </div>

        <div className="col-lg-12 col-md-12 col-sm-12 padding0 divide p-t1 m-b">
            <h3>Preference</h3>  
                <div className="col-lg-6 col-md-12 col-sm-12 p-t1 ">
                    <p>Default Landing Page</p>
                    <Select options={ Page } className="modal-input-cmp"placeholder="Change The Landing Page"/>
                </div>
            <div className="col-lg-6 col-md-12 col-sm-12 p-t1">
                <p>Default no. of records to fetch</p>
                <Select options={ Records } className="modal-input-cmp"placeholder=""/>                
                    
            </div>
            <div className="col-lg-12 col-md-12 col-sm-12 displayFlex">
            <div className="col-lg-4 col-md-4 col-sm-4 ">
            <Col xs="12" className="text-right p-t1">
                        <Button type="submit" color="danger" className="cancel">Cancel</Button>
                        <Button type="submit" color="success" className="edit">Edit</Button>
            </Col>
            </div>
            <div className="col-lg-4 col-md-4 col-sm-4 ">
            </div>
            <div className="col-lg-4 col-md-4 col-sm-4 ">
                <Col xs="12" className="text-right">
                    <Button type="save" color="info" className="save">Save</Button>
                </Col>
            </div>
            </div>
            </div>
        </div>  
        );
    }
  }
  
  export default MyAccount;