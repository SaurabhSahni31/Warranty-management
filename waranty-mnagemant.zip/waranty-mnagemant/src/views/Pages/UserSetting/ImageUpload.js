import React from 'react';
import { Button } from 'reactstrap';
import "./ImageUpload.css"

class ImageUpload extends React.Component {
    constructor(props) {
      super(props);
      this.state = {file: '',imagePreviewUrl: ''};
    }
  
    _handleSubmit(e) {
      e.preventDefault();
      console.log('handle uploading-', this.state.file);
    }
  
    _handleImageChange(e) {
      e.preventDefault();
  
      let reader = new FileReader();
      let file = e.target.files[0];
  
      reader.onloadend = () => {
        this.setState({
          file: file,
          imagePreviewUrl: reader.result
        });
      }
  
      reader.readAsDataURL(file)
    }
  
    render() {
      let {imagePreviewUrl} = this.state;
      let $imagePreview = null;
      if (imagePreviewUrl) {
        $imagePreview = (<img src={imagePreviewUrl} alt="preview" className="image" />);
      } else {
        $imagePreview = (<div className="previewText"></div>);
      }
  
      return (
        <div className="previewComponent">
          <form onSubmit={(e)=>this._handleSubmit(e)}>
          <div className="imgPreview">
                {$imagePreview}
            </div>
            <h3 className="textUpload">Upload or Change Image</h3>
            <input className="fileInput" 
              type="file" 
              onChange={(e)=>this._handleImageChange(e)} />  
            
            <Button className="submitButton save"
              type="submit" 
              color="info"
              onClick={(e)=>this._handleSubmit(e)}>Save</Button>
          </form>
        </div>
      )
    }
  }

export default ImageUpload;