import React, { Component } from 'react';
import { Card, CardImg, Label, Container, CardGroup, FormGroup, Input, Button, CardBody, Col, Form, Row } from 'reactstrap';
import { BrowserRouter as Link } from "react-router-dom";
import '../../../StyleSheet/Default.css';
import image from '../../../assets/img/1.png';

class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    } 

    submitForm(e) {
        e.preventDefault()
        this.props.history.push('../../Products/Products');
    }
    routeChange(e){
        e.preventDefault()
        this.props.history.push('../Register/Register')
    }
    render() {
        return (
            <div className="cmp-bgc" >
                <Container className="cmp-login-container">
                    <Row className="justify-content-center">
                        <Col xs="12"sm="12"md="12" lg="6">
                            <CardGroup>
                                <Card className="p-4">
                                    <CardBody>
                                        <Form onSubmit={this.submitForm.bind(this)}>
                                          <Row>
                                            <Col>
                                                <CardImg className="imgsize" alt='icon' src={image} size='100px'/>
                                            </Col>
                                            </Row>
                                            <p className="text-center cmp-signin">Log In</p>
                                            <Row>
                                                <Col xs="12" sm="12"md="12" lg="12">
                                                    <FormGroup>
                                                        <Label htmlFor="email" className="cmp-login-title">Email Address</Label>
                                                        <Input type="email" id="email" className="validate " required />
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Row>
                                                <Col xs="12" sm="12"md="12" lg="12">
                                                    <FormGroup>
                                                        <Label htmlFor="password" className="cmp-login-title">Password</Label>
                                                        <Input type="password" id="password" required />
                                                        <Button color="link" className="cmp-login-title px-0" >Forgot password?</Button>
                                                    </FormGroup>
                                                </Col>
                                            </Row>
                                            <Col xs="12" className="text-right">
                                                <Button type="submit" color="info" className="px-4">Login</Button>
                                                
                                            </Col>
                                        </Form>
                                    </CardBody>
                                </Card>
                            </CardGroup>
                            <p class="text-center signup">Don't have an account?&nbsp;&nbsp;
                              
                          <Button href="/login#/register" color="link" className="px-0" >Sign Up</Button>
                            </p>
                            <p className="about"><Link to="/">About cmPlify</Link>.<Link to="/">Terms</Link>.<Link to="/">Help</Link></p>
                        </Col>
                    </Row>

                </Container>
                </div>
          
        )
    }
}
export default Login